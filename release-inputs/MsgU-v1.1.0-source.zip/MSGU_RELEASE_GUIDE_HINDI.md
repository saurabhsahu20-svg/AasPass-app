# MsgU v1.1.0 beta – Android बिल्ड और GitHub Release

यह प्रोजेक्ट आपकी 19 नवंबर 2026, 8:26 PM वाली ZIP पर आधारित है।

## इस अपडेट में क्या बदला
- Kotlin में अनुपस्थित `kotlinx-coroutines-play-services` dependency जोड़ी, जो Firestore `.await()` को चाहिए।
- `versionCode` 1 → 2 और `versionName` 1.0 → 1.1.0-beta किया।
- 50 मैसेज तक सीमित Read Receipts को 400-400 के बैच में बदला।
- Emoji Reaction update में Firestore transaction लगाकर stale-data overwrite रोका।
- Failed message Retry के लिए idempotent transaction जोड़ा; पहला send offline queue ही उपयोग करता है।
- Blocked contact को मैसेज भेजने पर Draft गलती से साफ न हो, यह सुधारा।
- GitHub Actions: Android Gradle build, unit tests, APK checksum और tag पर प्री-रिलीज।

## GitHub Release कैसे बनेगी

1. इस ZIP की files **उसी MsgU source repository** में push करें (पुराना AasPass backend इस प्रोजेक्ट से अलग है)।
2. `app/google-services.json` को पब्लिक रिपॉजिटरी में commit नहीं करना चाहिए। GitHub Actions में `MSGU_GOOGLE_SERVICES_JSON_B64` नाम का repository secret बनाकर उस फाइल का Base64 text रखें।
3. Actions > `MsgU native Android build and APK pre-release` में build run करें और Errors ठीक करें।
4. Builds successful होने पर tag `msgu-v1.1.0-beta` push करें। केवल सफल build के बाद Workflow GitHub pre-release में APK और SHA256 अपलोड करेगा।
5. **महत्त्वपूर्ण:** CI की APK केवल *Debug Test Build* है। पुरानी AI Studio APK के ऊपर install होने के लिए original keystore और signing certificate आवश्यक हैं। CI की नई debug signing key पुरानी release key से मेल नहीं खाएगी।
6. Google Login का SHA fingerprint भी नए signing certificate के लिए Firebase में जोड़ना पड़ सकता है। APK बनना और वास्तविक दो-फोन चैट सफल होना अलग चरण हैं।

## वर्तमान सत्यापन

इस कंटेनर में Android SDK उपलब्ध नहीं है, और repository से dependency download करने का नेटवर्क भी बंद है। इसलिए `gradle assembleDebug` और फोन पर चैटिंग टेस्ट यहाँ नहीं हो सके। यह ZIP **source update**, APK नहीं है।

## सुरक्षा

Supabase/Firestore का Admin secret, Gemini API key या release signing key GitHub में public commit न करें। Firebase client `google-services.json` को निजी CI secret से inject करें।
