package com.example.data.firebase

import com.example.data.model.ChatMessage
import com.example.data.model.ChatMessageUi
import com.example.data.model.Conversation
import com.example.data.model.EmojiCatalog
import com.example.data.model.MessageDeliveryStatus
import com.example.data.model.MessageType
import com.example.data.model.ReplyTarget
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class ChatRepository(
  private val db: FirebaseFirestore,
  private val auth: FirebaseAuth = Firebase.auth,
) {
  companion object {
    fun deterministicConversationId(uidA: String, uidB: String): String {
      val sorted = listOf(uidA, uidB).sorted()
      return "${sorted[0]}_${sorted[1]}"
    }
  }

  private fun requireUserId(): String =
    auth.currentUser?.uid
      ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")

  fun observeConversations(currentUserId: String): Flow<List<Conversation>> = flow {
    val uid = requireUserId()
    check(uid == currentUserId) { "Authenticated user mismatch" }
    val path = "conversations"
    emitAll(
      db.collection(path)
        .whereArrayContains("participantUids", currentUserId)
        .snapshots()
        .map { snapshot ->
          snapshot
            .toObjects(Conversation::class.java, ServerTimestampBehavior.ESTIMATE)
            .sortedByDescending { conv ->
              conv.lastMessageAt ?: conv.updatedAt ?: conv.createdAt ?: Timestamp(0, 0)
            }
        }
        .catch { error ->
          val firestoreError =
            generateSequence(error) { it.cause }
              .filterIsInstance<FirebaseFirestoreException>()
              .firstOrNull()
          if (firestoreError == null && error is CancellationException) throw error
          val ex = firestoreError ?: (error as? Exception)
          if (ex != null && auth.currentUser?.uid == currentUserId) {
            handleFirestoreError(ex, OperationType.LIST, path)
          }
          throw error
        }
    )
  }

  fun observeConversation(conversationId: String): Flow<Conversation?> = flow {
    val uid = requireUserId()
    val docRef = db.collection("conversations").document(conversationId)
    emitAll(
      docRef
        .snapshots()
        .map { snapshot ->
          if (snapshot.exists()) {
            snapshot.toObject(Conversation::class.java, ServerTimestampBehavior.ESTIMATE)
          } else {
            null
          }
        }
        .catch { error ->
          val firestoreError =
            generateSequence(error) { it.cause }
              .filterIsInstance<FirebaseFirestoreException>()
              .firstOrNull()
          if (firestoreError == null && error is CancellationException) throw error
          val ex = firestoreError ?: (error as? Exception)
          if (ex != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(ex, OperationType.GET, docRef.path)
          }
          throw error
        }
    )
  }

  fun observeMessages(conversationId: String, currentUserId: String): Flow<List<ChatMessageUi>> =
    flow {
      val uid = requireUserId()
      check(uid == currentUserId) { "Authenticated user mismatch" }
      val path = "conversations/$conversationId/messages"
      emitAll(
        db.collection("conversations")
          .document(conversationId)
          .collection("messages")
          .whereArrayContains("participantUids", currentUserId)
          .snapshots(MetadataChanges.INCLUDE)
          .map { snapshot ->
            snapshot.documents
              .mapNotNull { doc ->
                val message =
                  doc.toObject(ChatMessage::class.java, ServerTimestampBehavior.ESTIMATE)
                    ?: return@mapNotNull null
                val hasPending = doc.metadata.hasPendingWrites()
                val status =
                  when {
                    hasPending -> MessageDeliveryStatus.SENDING
                    message.senderId == currentUserId &&
                      message.readBy.any { readerUid -> readerUid != currentUserId } ->
                      MessageDeliveryStatus.READ
                    else -> MessageDeliveryStatus.SENT
                  }
                ChatMessageUi(
                  message = message,
                  status = status,
                  isFromCache = doc.metadata.isFromCache,
                )
              }
              .distinctBy { it.message.clientMessageId.ifBlank { it.message.id } }
              .sortedWith(
                compareBy<ChatMessageUi>(
                  { it.message.createdAt?.seconds ?: (it.message.clientTimestampMs / 1000L) },
                  { it.message.createdAt?.nanoseconds ?: 0 },
                  { it.message.clientTimestampMs },
                )
              )
          }
          .catch { error ->
            val firestoreError =
              generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val ex = firestoreError ?: (error as? Exception)
            if (ex != null && auth.currentUser?.uid == currentUserId) {
              handleFirestoreError(ex, OperationType.LIST, path)
            }
            throw error
          }
      )
    }

  suspend fun ensureConversation(
    currentUser: UserProfile,
    peerUser: UserProfile,
  ): Result<String> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
    val conversationId = deterministicConversationId(currentUser.userId, peerUser.userId)
    val docRef = db.collection("conversations").document(conversationId)
    return try {
      requireUserId()
      check(uid == currentUser.userId) { "Current user mismatch" }
      require(peerUser.userId.isNotBlank() && peerUser.userId != currentUser.userId) {
        "Cannot start a conversation with this account."
      }
      val sortedUids = listOf(currentUser.userId, peerUser.userId).sorted()
      val namesMap =
        mapOf(
          currentUser.userId to currentUser.displayName.take(50),
          peerUser.userId to peerUser.displayName.take(50),
        )
      val usernamesMap =
        mapOf(
          currentUser.userId to currentUser.username,
          peerUser.userId to peerUser.username,
        )
      val photosMap =
        buildMap<String, String> {
          if (currentUser.photoUrl.isNotBlank()) put(currentUser.userId, currentUser.photoUrl.take(500))
          if (peerUser.photoUrl.isNotBlank()) put(peerUser.userId, peerUser.photoUrl.take(500))
        }

      val existing = docRef.get().await()
      if (!existing.exists()) {
        val createPayload =
          buildMap<String, Any> {
            put("participantUids", sortedUids)
            put("participantNames", namesMap)
            put("participantUsernames", usernamesMap)
            if (photosMap.isNotEmpty()) put("participantPhotos", photosMap)
            put("lastMessageText", "")
            put("lastMessageSenderId", "")
            put("lastMessageType", "NONE")
            put("lastMessageAt", FieldValue.serverTimestamp())
            put("unreadCounts", mapOf(currentUser.userId to 0L, peerUser.userId to 0L))
            put("createdAt", FieldValue.serverTimestamp())
            put("updatedAt", FieldValue.serverTimestamp())
          }
        try {
          docRef.set(createPayload).await()
        } catch (createErr: FirebaseFirestoreException) {
          // If the peer created this deterministic conversation simultaneously, verify it now exists.
          if (createErr.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
            val recheck = docRef.get().await()
            if (!recheck.exists()) throw createErr
          } else {
            throw createErr
          }
        }
      } else {
        val updatePayload =
          buildMap<String, Any> {
            put("participantNames", namesMap)
            put("participantUsernames", usernamesMap)
            if (photosMap.isNotEmpty()) put("participantPhotos", photosMap)
            put("updatedAt", FieldValue.serverTimestamp())
          }
        docRef.update(updatePayload).await()
      }
      Result.success(conversationId)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun sendMessage(
    conversationId: String,
    currentUser: UserProfile,
    peerUser: UserProfile,
    text: String,
    messageType: MessageType,
    clientMessageId: String,
    clientTimestampMs: Long,
    replyTo: ReplyTarget? = null,
    conversationAlreadyExists: Boolean = false,
    isRetry: Boolean = false,
  ): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
    val cleanText = text.trim()
    val messagePath = "conversations/$conversationId/messages/$clientMessageId"
    return try {
      requireUserId()
      check(uid == currentUser.userId) { "Authenticated user mismatch" }
      require(cleanText.isNotEmpty() && cleanText.length <= 2000) {
        "Message must be between 1 and 2000 characters."
      }
      require(clientMessageId.isNotBlank() && clientMessageId.length <= 128) {
        "Invalid clientMessageId."
      }

      val sortedUids = listOf(currentUser.userId, peerUser.userId).sorted()
      val convRef = db.collection("conversations").document(conversationId)
      if (!conversationAlreadyExists) {
        val convSnap = convRef.get().await()
        if (!convSnap.exists()) {
          ensureConversation(currentUser, peerUser).getOrThrow()
        }
      }

      val msgRef = convRef.collection("messages").document(clientMessageId)
      val messagePayload =
        buildMap<String, Any> {
          put("conversationId", conversationId)
          put("participantUids", sortedUids)
          put("senderId", uid)
          put("text", cleanText)
          put("messageType", messageType.name)
          put("clientMessageId", clientMessageId)
          put("clientTimestampMs", clientTimestampMs)
          put("readBy", listOf(uid))
          if (replyTo != null) {
            put("replyToMessageId", replyTo.messageId.take(128))
            put("replyToText", replyTo.previewText.take(300))
            put("replyToSenderId", replyTo.senderId.take(128))
          }
          put("createdAt", FieldValue.serverTimestamp())
          put("updatedAt", FieldValue.serverTimestamp())
        }

      val previewText = EmojiCatalog.previewLabel(cleanText, messageType).take(500)
      val conversationUpdate =
        mapOf(
          "lastMessageText" to previewText,
          "lastMessageSenderId" to uid,
          "lastMessageType" to messageType.name,
          "lastMessageAt" to FieldValue.serverTimestamp(),
          "unreadCounts.${peerUser.userId}" to FieldValue.increment(1L),
          "unreadCounts.$uid" to 0L,
          "typingBy.$uid" to FieldValue.delete(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      if (isRetry) {
        // A confirmed retry can check whether the original write already reached
        // the server. This keeps unread count increments idempotent on retries.
        // Transactions require connectivity; normal first-time sends still use
        // Firestore's offline write queue.
        db.runTransaction { transaction ->
          val existing = transaction.get(msgRef)
          if (existing.exists()) {
            check(existing.getString("senderId") == uid &&
              existing.getString("text") == cleanText &&
              existing.getString("messageType") == messageType.name
            ) { "A different message already uses this ID." }
          } else {
            transaction.set(msgRef, messagePayload)
            transaction.update(convRef, conversationUpdate)
          }
        }.await()
      } else {
        val batch = db.batch()
        batch.set(msgRef, messagePayload)
        batch.update(convRef, conversationUpdate)
        batch.commit().await()
      }
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, messagePath)
      Result.failure(e)
    }
  }

  suspend fun setTypingStatus(
    conversationId: String,
    currentUserId: String,
    isTyping: Boolean,
  ): Result<Unit> {
    val convRef = db.collection("conversations").document(conversationId)
    return try {
      val uid = requireUserId()
      if (uid != currentUserId) return Result.success(Unit)
      convRef
        .update(
          mapOf(
            "typingBy.$uid" to if (isTyping) FieldValue.serverTimestamp() else FieldValue.delete(),
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        )
        .await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      // Typing indicator is best-effort; never interrupt user chatting.
      Result.failure(e)
    }
  }

  suspend fun markMessagesAsRead(
    conversationId: String,
    currentUserId: String,
    unreadMessages: List<ChatMessage>,
    conversationUnreadCount: Long,
  ): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
    val convRef = db.collection("conversations").document(conversationId)
    return try {
      requireUserId()
      check(uid == currentUserId) { "Authenticated user mismatch" }
      val idsToMark = unreadMessages.asSequence()
        .filter { it.senderId != currentUserId && currentUserId !in it.readBy }
        .map { it.id }
        .filter { it.isNotBlank() }
        .distinct()
        .toList()
      if (idsToMark.isEmpty() && conversationUnreadCount <= 0L) {
        return Result.success(Unit)
      }
      // Respect Firestore's maximum 500 writes per batch. Mark all observed
      // messages, not only the first 50, to avoid missing read receipts.
      ChatMutationRules.readBatches(idsToMark).forEach { group ->
        val batch = db.batch()
        group.forEach { messageId ->
          batch.update(
            convRef.collection("messages").document(messageId),
            mapOf(
              "readBy" to FieldValue.arrayUnion(currentUserId),
              "updatedAt" to FieldValue.serverTimestamp(),
            ),
          )
        }
        batch.commit().await()
      }
      if (conversationUnreadCount > 0L) {
        // Clear only after the receipt writes complete successfully.
        convRef.update(
          mapOf(
            "unreadCounts.$currentUserId" to 0L,
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        ).await()
      }
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, convRef.path)
      Result.failure(e)
    }
  }

  suspend fun toggleReaction(
    conversationId: String,
    messageId: String,
    currentUserId: String,
    emoji: String,
  ): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
    val msgRef = db.collection("conversations").document(conversationId).collection("messages").document(messageId)
    return try {
      requireUserId()
      check(uid == currentUserId) { "Authenticated user mismatch" }
      // Read the latest reactions within the transaction; otherwise a stale
      // client's update can overwrite the peer's reaction.
      db.runTransaction { transaction ->
        val snapshot = transaction.get(msgRef)
        if (!snapshot.exists()) error("Message is no longer available.")
        @Suppress("UNCHECKED_CAST")
        val latest = (snapshot.get("reactions") as? Map<String, String>).orEmpty()
        val updated = ChatMutationRules.toggleReaction(latest, currentUserId, emoji)
        transaction.update(
          msgRef,
          mapOf(
            "reactions" to updated,
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        )
      }.await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, msgRef.path)
      Result.failure(e)
    }
  }
}
