package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.ChatMessage
import com.example.data.model.EmojiCatalog
import com.example.data.model.MessageType
import com.example.data.model.ReplyTarget
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.ui.components.ChatMessageBubble
import com.example.ui.components.MsgUAvatar
import com.example.ui.components.MsgUEmojiKeyboard
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.ChatViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
  viewModel: ChatViewModel,
  onBack: () -> Unit,
  onOpenContactProfile: (UserProfile) -> Unit,
) {
  val conversationState by viewModel.conversationState.collectAsStateWithLifecycle()
  val messagesState by viewModel.messagesState.collectAsStateWithLifecycle()
  val peerProfile by viewModel.peerProfile.collectAsStateWithLifecycle()
  val draftText by viewModel.draftText.collectAsStateWithLifecycle()
  val replyTarget by viewModel.replyTarget.collectAsStateWithLifecycle()
  val isPeerBlocked by viewModel.isPeerBlocked.collectAsStateWithLifecycle()
  val isPeerFavorite by viewModel.isPeerFavorite.collectAsStateWithLifecycle()
  val actionError by viewModel.actionError.collectAsStateWithLifecycle()
  val actionFeedback by viewModel.actionFeedback.collectAsStateWithLifecycle()
  val recentEmojis by viewModel.recentEmojis.collectAsStateWithLifecycle()
  val favoriteEmojis by viewModel.favoriteEmojis.collectAsStateWithLifecycle()

  val conversation = (conversationState as? UiState.Success)?.data
  val peerName =
    peerProfile?.displayName
      ?: conversation?.peerDisplayName(viewModel.currentUserId)
      ?: "MsgU User"
  val peerUsername =
    peerProfile?.username ?: conversation?.peerUsername(viewModel.currentUserId).orEmpty()
  val peerPhoto =
    peerProfile?.photoUrl ?: conversation?.peerPhotoUrl(viewModel.currentUserId).orEmpty()

  var showEmojiPicker by remember { mutableStateOf(false) }
  var showOptionsMenu by remember { mutableStateOf(false) }
  var selectedMessageForActions by remember { mutableStateOf<ChatMessage?>(null) }
  var showReportDialog by remember { mutableStateOf(false) }
  var reportReason by remember { mutableStateOf("") }

  val listState = rememberLazyListState()
  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()
  val haptic = LocalHapticFeedback.current

  LaunchedEffect(actionError, actionFeedback) {
    val msg = actionError ?: actionFeedback
    if (!msg.isNullOrBlank()) {
      snackbarHostState.showSnackbar(msg)
      viewModel.clearMessages()
    }
  }

  val messages = (messagesState as? UiState.Success)?.data.orEmpty()
  val conversationUnread = conversation?.unreadCountFor(viewModel.currentUserId) ?: 0L
  val isPeerTyping = conversation?.isPeerTyping(viewModel.currentUserId) == true
  val peerLastActiveMs = peerProfile?.lastActiveAt?.toDate()?.time
  val isPeerOnline =
    peerLastActiveMs != null && (System.currentTimeMillis() - peerLastActiveMs) < 95_000L

  val isNearBottom by remember {
    derivedStateOf {
      val layoutInfo = listState.layoutInfo
      val lastVisible = layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
      layoutInfo.totalItemsCount == 0 || lastVisible >= layoutInfo.totalItemsCount - 3
    }
  }

  var unseenBelowCount by remember { mutableIntStateOf(0) }
  var previousMessageCount by remember { mutableIntStateOf(0) }

  val unreadIncomingKey =
    remember(messages, viewModel.currentUserId) {
      messages
        .filter {
          it.message.senderId != viewModel.currentUserId &&
            !it.message.readBy.contains(viewModel.currentUserId)
        }
        .map { it.message.id }
    }

  LaunchedEffect(messages.size) {
    if (messages.isNotEmpty()) {
      val lastMsg = messages.last()
      val isFirstLoad = previousMessageCount == 0
      val sentByMe = lastMsg.message.senderId == viewModel.currentUserId
      if (isFirstLoad || isNearBottom || sentByMe) {
        if (isFirstLoad) listState.scrollToItem(messages.lastIndex)
        else listState.animateScrollToItem(messages.lastIndex)
        unseenBelowCount = 0
      } else if (messages.size > previousMessageCount) {
        unseenBelowCount += (messages.size - previousMessageCount)
      }
      previousMessageCount = messages.size
    }
  }

  LaunchedEffect(isNearBottom) {
    if (isNearBottom) unseenBelowCount = 0
  }

  LaunchedEffect(unreadIncomingKey, conversationUnread) {
    if (unreadIncomingKey.isNotEmpty() || conversationUnread > 0L) {
      viewModel.markVisibleMessagesRead(messages, conversationUnread)
    }
  }

  Scaffold(
    snackbarHost = { SnackbarHost(snackbarHostState) },
    topBar = {
      TopAppBar(
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("chat_back_button")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        title = {
          Row(
            modifier =
              Modifier.clickable {
                  val target =
                    peerProfile
                      ?: UserProfile(
                        userId = viewModel.peerUserId,
                        username = peerUsername,
                        displayName = peerName,
                        photoUrl = peerPhoto,
                      )
                  onOpenContactProfile(target)
                }
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Box {
              MsgUAvatar(displayName = peerName, photoUrl = peerPhoto, size = 38.dp)
              if (isPeerOnline || isPeerTyping) {
                Box(
                  modifier =
                    Modifier.align(Alignment.BottomEnd)
                      .size(11.dp)
                      .clip(CircleShape)
                      .background(MaterialTheme.colorScheme.surface)
                      .padding(1.5.dp)
                      .clip(CircleShape)
                      .background(SuccessGreen)
                )
              }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = peerName,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              val statusText =
                when {
                  isPeerTyping -> "typing…"
                  isPeerOnline -> "Online"
                  peerLastActiveMs != null -> formatLastSeen(peerLastActiveMs)
                  peerUsername.isNotBlank() -> "@$peerUsername"
                  else -> ""
                }
              if (statusText.isNotBlank()) {
                Text(
                  text = statusText,
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = if (isPeerTyping) FontWeight.Bold else FontWeight.Medium,
                  color =
                    when {
                      isPeerTyping -> MaterialTheme.colorScheme.primary
                      isPeerOnline -> SuccessGreen
                      else -> MaterialTheme.colorScheme.onSurfaceVariant
                    },
                )
              }
            }
          }
        },
        actions = {
          Box {
            IconButton(
              onClick = { showOptionsMenu = true },
              modifier = Modifier.testTag("chat_more_button"),
            ) {
              Icon(Icons.Default.MoreVert, contentDescription = "More Options")
            }
            DropdownMenu(
              expanded = showOptionsMenu,
              onDismissRequest = { showOptionsMenu = false },
            ) {
              DropdownMenuItem(
                text = { Text("View Profile") },
                onClick = {
                  showOptionsMenu = false
                  onOpenContactProfile(
                    peerProfile
                      ?: UserProfile(
                        userId = viewModel.peerUserId,
                        username = peerUsername,
                        displayName = peerName,
                        photoUrl = peerPhoto,
                      )
                  )
                },
              )
              DropdownMenuItem(
                text = { Text(if (isPeerFavorite) "Remove Favorite" else "Add to Favorites") },
                onClick = {
                  showOptionsMenu = false
                  viewModel.toggleFavorite()
                },
              )
              DropdownMenuItem(
                text = { Text(if (isPeerBlocked) "Unblock User" else "Block User") },
                onClick = {
                  showOptionsMenu = false
                  viewModel.toggleBlocked()
                },
              )
              DropdownMenuItem(
                text = { Text("Report User") },
                onClick = {
                  showOptionsMenu = false
                  showReportDialog = true
                },
              )
            }
          }
        },
      )
    },
    bottomBar = {
      Column(
        modifier =
          Modifier.fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .navigationBarsPadding()
            .imePadding()
      ) {
        if (isPeerBlocked) {
          Surface(
            color = MaterialTheme.colorScheme.error.copy(alpha = 0.12f),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  Icons.Default.Block,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.error,
                  modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "You blocked $peerName",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.error,
                )
              }
              TextButton(onClick = viewModel::toggleBlocked) {
                Text("Unblock")
              }
            }
          }
        } else {
          AnimatedVisibility(visible = replyTarget != null) {
            val target = replyTarget
            if (target != null) {
              Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                modifier = Modifier.fillMaxWidth(),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Icon(
                    Icons.AutoMirrored.Filled.Reply,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp),
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = "Replying to ${target.senderName}",
                      style = MaterialTheme.typography.labelSmall,
                      fontWeight = FontWeight.Bold,
                      color = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                      text = target.previewText,
                      style = MaterialTheme.typography.bodySmall,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                  }
                  IconButton(onClick = { viewModel.setReplyTarget(null) }) {
                    Icon(Icons.Default.Close, contentDescription = "Cancel reply", modifier = Modifier.size(18.dp))
                  }
                }
              }
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.Bottom,
          ) {
            IconButton(
              onClick = { showEmojiPicker = !showEmojiPicker },
              modifier = Modifier.testTag("toggle_emoji_button"),
            ) {
              Icon(
                imageVector =
                  if (showEmojiPicker) Icons.Default.Keyboard else Icons.Default.EmojiEmotions,
                contentDescription = "MsgU Emoji Keyboard",
                tint = MaterialTheme.colorScheme.primary,
              )
            }

            OutlinedTextField(
              value = draftText,
              onValueChange = viewModel::onDraftChanged,
              placeholder = { Text(stringResource(id = R.string.hint_type_message)) },
              maxLines = 4,
              shape = RoundedCornerShape(24.dp),
              colors =
                OutlinedTextFieldDefaults.colors(
                  focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                  unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                  focusedBorderColor = MaterialTheme.colorScheme.primary,
                  unfocusedBorderColor = Color.Transparent,
                ),
              keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
              keyboardActions =
                KeyboardActions(
                  onSend = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    viewModel.sendTextMessage()
                  }
                ),
              modifier = Modifier.weight(1f).testTag("message_input"),
            )

            Spacer(modifier = Modifier.width(6.dp))

            val canSend = draftText.trim().isNotEmpty()
            Surface(
              shape = CircleShape,
              color =
                if (canSend) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.surfaceVariant,
              modifier =
                Modifier.size(48.dp)
                  .clip(CircleShape)
                  .clickable(enabled = canSend) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    viewModel.sendTextMessage()
                  }
                  .testTag("send_message_button"),
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.AutoMirrored.Filled.Send,
                  contentDescription = stringResource(id = R.string.action_send),
                  tint =
                    if (canSend) MaterialTheme.colorScheme.onPrimary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.size(20.dp),
                )
              }
            }
          }

          AnimatedVisibility(visible = showEmojiPicker) {
            MsgUEmojiKeyboard(
              recentEmojis = recentEmojis,
              favoriteEmojis = favoriteEmojis,
              onInsertUnicode = viewModel::appendEmojiToDraft,
              onSendCustomEmoji = { token, type ->
                viewModel.sendCustomEmoji(token, type)
              },
              onToggleFavoriteEmoji = viewModel::toggleFavoriteEmoji,
            )
          }
        }
      }
    },
  ) { innerPadding ->
    Box(
      modifier =
        Modifier.fillMaxSize()
          .padding(innerPadding)
          .background(MaterialTheme.colorScheme.background)
    ) {
      when (messagesState) {
        is UiState.Loading -> {
          CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
        }
        is UiState.Error -> {
          Text(
            text = (messagesState as UiState.Error).message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.error,
            modifier = Modifier.align(Alignment.Center).padding(24.dp),
          )
        }
        is UiState.Success -> {
          if (messages.isEmpty()) {
            Column(
              modifier = Modifier.align(Alignment.Center).padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
            ) {
              Text(
                text = "Say hello to $peerName",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "Send a message or tap 😊 to drop a Crystal Jelly 3D emoji.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          } else {
            LazyColumn(
              state = listState,
              modifier = Modifier.fillMaxSize(),
              contentPadding = PaddingValues(vertical = 10.dp),
            ) {
              items(
                items = messages,
                key = { it.message.clientMessageId.ifBlank { it.message.id } },
              ) { item ->
                ChatMessageBubble(
                  item = item,
                  isMine = item.message.senderId == viewModel.currentUserId,
                  peerName = peerName,
                  onLongPress = { selectedMessageForActions = it },
                  onRetryFailed = viewModel::retryFailedMessage,
                  onReactionClick = viewModel::toggleReaction,
                )
              }
            }

            if (!isNearBottom && messages.size > 4) {
              Box(
                modifier = Modifier.align(Alignment.BottomEnd).padding(14.dp),
              ) {
                SmallFloatingActionButton(
                  onClick = {
                    scope.launch {
                      listState.animateScrollToItem(messages.lastIndex)
                      unseenBelowCount = 0
                    }
                  },
                  containerColor = MaterialTheme.colorScheme.surface,
                  contentColor = MaterialTheme.colorScheme.primary,
                ) {
                  Icon(
                    imageVector = Icons.Default.KeyboardArrowDown,
                    contentDescription = "Jump to latest message",
                  )
                }
                if (unseenBelowCount > 0) {
                  Box(
                    modifier =
                      Modifier.align(Alignment.TopEnd)
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(ErrorRed),
                    contentAlignment = Alignment.Center,
                  ) {
                    Text(
                      text = unseenBelowCount.coerceAtMost(99).toString(),
                      style = MaterialTheme.typography.labelSmall,
                      color = Color.White,
                      fontWeight = FontWeight.Bold,
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  val actionMsg = selectedMessageForActions
  if (actionMsg != null) {
    ModalBottomSheet(onDismissRequest = { selectedMessageForActions = null }) {
      Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp)) {
        Text(
          text = "React",
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          EmojiCatalog.quickReactions.forEach { emoji ->
            Surface(
              shape = CircleShape,
              color = MaterialTheme.colorScheme.surfaceVariant,
              onClick = {
                viewModel.toggleReaction(actionMsg, emoji)
                selectedMessageForActions = null
              },
              modifier = Modifier.size(48.dp),
            ) {
              Box(contentAlignment = Alignment.Center) {
                Text(text = emoji, fontSize = 22.sp)
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Button(
          onClick = {
            val preview =
              EmojiCatalog.previewLabel(actionMsg.text, MessageType.fromRaw(actionMsg.messageType))
            val senderName =
              if (actionMsg.senderId == viewModel.currentUserId) "You" else peerName
            viewModel.setReplyTarget(
              ReplyTarget(
                messageId = actionMsg.id.ifBlank { actionMsg.clientMessageId },
                previewText = preview,
                senderId = actionMsg.senderId,
                senderName = senderName,
              )
            )
            selectedMessageForActions = null
          },
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth().height(48.dp),
        ) {
          Icon(Icons.AutoMirrored.Filled.Reply, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Reply to Message")
        }
        Spacer(modifier = Modifier.height(16.dp))
      }
    }
  }

  if (showReportDialog) {
    AlertDialog(
      onDismissRequest = { showReportDialog = false },
      title = { Text("Report $peerName") },
      text = {
        OutlinedTextField(
          value = reportReason,
          onValueChange = { reportReason = it.take(500) },
          label = { Text("Reason") },
          maxLines = 4,
          modifier = Modifier.fillMaxWidth(),
        )
      },
      confirmButton = {
        Button(
          onClick = {
            if (reportReason.trim().length >= 3) {
              viewModel.reportPeer(reportReason)
              reportReason = ""
              showReportDialog = false
            }
          },
          enabled = reportReason.trim().length >= 3,
        ) {
          Text("Submit")
        }
      },
      dismissButton = {
        TextButton(onClick = { showReportDialog = false }) { Text("Cancel") }
      },
    )
  }
}

private fun formatLastSeen(lastActiveMs: Long): String {
  val diffMs = (System.currentTimeMillis() - lastActiveMs).coerceAtLeast(0L)
  val minutes = diffMs / 60_000L
  return when {
    minutes < 1L -> "Last seen just now"
    minutes < 60L -> "Last seen ${minutes}m ago"
    minutes < 24L * 60L -> "Last seen ${minutes / 60L}h ago"
    else -> "Last seen ${minutes / (24L * 60L)}d ago"
  }
}
