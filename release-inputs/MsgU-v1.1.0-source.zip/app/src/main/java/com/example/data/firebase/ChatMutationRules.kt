package com.example.data.firebase

/** Small, deterministic helpers shared by Firestore mutations and local tests. */
internal object ChatMutationRules {
  // Leave room below Firestore's batch limit (500) for future companion writes.
  const val MAX_READS_PER_BATCH = 400

  fun readBatches(messageIds: List<String>): List<List<String>> =
    messageIds.asSequence().filter { it.isNotBlank() }.distinct().toList().chunked(MAX_READS_PER_BATCH)

  fun toggleReaction(
    existing: Map<String, String>,
    currentUserId: String,
    emoji: String,
  ): Map<String, String> {
    require(currentUserId.isNotBlank()) { "User ID is required" }
    require(emoji.isNotBlank() && emoji.length <= 16) { "Invalid reaction" }
    val updated = existing.toMutableMap()
    if (updated[currentUserId] == emoji) updated.remove(currentUserId)
    else updated[currentUserId] = emoji
    return updated
  }
}
