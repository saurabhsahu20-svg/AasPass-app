package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

private val AvatarGradients =
  listOf(
    listOf(Color(0xFF0B63F6), Color(0xFF00B4D8)),
    listOf(Color(0xFF2563EB), Color(0xFF38BDF8)),
    listOf(Color(0xFF0284C7), Color(0xFF2DD4BF)),
    listOf(Color(0xFF4F46E5), Color(0xFF22D3EE)),
    listOf(Color(0xFF0D9488), Color(0xFF0EA5E9)),
  )

@Composable
fun MsgUAvatar(
  displayName: String,
  photoUrl: String,
  size: Dp = 48.dp,
  modifier: Modifier = Modifier,
  showRing: Boolean = false,
) {
  val initials =
    remember(displayName) {
      displayName
        .trim()
        .split(Regex("\\s+"))
        .filter { it.isNotBlank() }
        .take(2)
        .map { it.first().uppercaseChar() }
        .joinToString("")
        .ifEmpty { "M" }
    }
  val palette =
    remember(displayName) {
      val idx = (displayName.hashCode().let { if (it < 0) -it else it }) % AvatarGradients.size
      AvatarGradients[idx]
    }

  Box(
    modifier =
      modifier
        .size(size)
        .clip(CircleShape)
        .background(Brush.linearGradient(palette))
        .then(
          if (showRing) {
            Modifier.border(2.dp, MaterialTheme.colorScheme.secondary, CircleShape)
          } else {
            Modifier
          }
        ),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = initials,
      color = Color.White,
      fontWeight = FontWeight.Bold,
      fontSize = (size.value * 0.36f).sp,
    )
    if (photoUrl.isNotBlank()) {
      AsyncImage(
        model = photoUrl,
        contentDescription = "$displayName profile photo",
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize().clip(CircleShape),
      )
    }
  }
}
