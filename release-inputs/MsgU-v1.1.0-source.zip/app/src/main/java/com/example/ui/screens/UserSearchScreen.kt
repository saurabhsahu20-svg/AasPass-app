package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PersonSearch
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.UserProfile
import com.example.ui.components.MsgUAvatar
import com.example.ui.viewmodel.HomeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserSearchScreen(
  viewModel: HomeViewModel,
  onBack: () -> Unit,
  onOpenChat: (conversationId: String, peerUid: String) -> Unit,
  onOpenProfile: (UserProfile) -> Unit,
) {
  val searchState by viewModel.searchState.collectAsStateWithLifecycle()

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Find People on MsgU") },
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("search_back_button")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
      )
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      Column(
        modifier = Modifier.widthIn(max = 600.dp).fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        OutlinedTextField(
          value = searchState.query,
          onValueChange = viewModel::updateSearchQuery,
          label = { Text("Exact @username") },
          placeholder = { Text(stringResource(id = R.string.hint_search_username)) },
          leadingIcon = { Icon(Icons.Default.AlternateEmail, contentDescription = null) },
          trailingIcon = {
            IconButton(
              onClick = viewModel::performUserSearch,
              enabled = !searchState.isSearching,
              modifier = Modifier.testTag("search_submit_button"),
            ) {
              if (searchState.isSearching) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
              } else {
                Icon(Icons.Default.Search, contentDescription = "Search username")
              }
            }
          },
          singleLine = true,
          keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
          keyboardActions = KeyboardActions(onSearch = { viewModel.performUserSearch() }),
          shape = RoundedCornerShape(18.dp),
          modifier = Modifier.fillMaxWidth().testTag("search_username_input"),
        )

        Spacer(modifier = Modifier.height(12.dp))

        Button(
          onClick = viewModel::performUserSearch,
          enabled = !searchState.isSearching && searchState.query.isNotBlank(),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("search_username_button"),
        ) {
          Text(if (searchState.isSearching) "Searching Firebase…" else "Search Username")
        }

        Spacer(modifier = Modifier.height(24.dp))

        if (!searchState.errorMessage.isNullOrBlank()) {
          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(
              modifier = Modifier.padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
            ) {
              Icon(
                imageVector = Icons.Default.PersonSearch,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(40.dp),
              )
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = searchState.errorMessage!!,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }

        val found = searchState.foundUser
        if (found != null) {
          val isSelf = found.userId == viewModel.currentUserId
          Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth().testTag("search_result_card"),
          ) {
            Column(modifier = Modifier.padding(20.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                MsgUAvatar(
                  displayName = found.displayName,
                  photoUrl = found.photoUrl,
                  size = 58.dp,
                  showRing = true,
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = found.displayName,
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                  )
                  Text(
                    text = "@${found.username}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                  )
                  if (found.bio.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                      text = found.bio,
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.height(18.dp))

              if (isSelf) {
                Text(
                  text = "This is your own MsgU account.",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              } else {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                  OutlinedButton(
                    onClick = {
                      viewModel.savePeerAsContact(found)
                      onOpenProfile(found)
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f).height(48.dp),
                  ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Profile")
                  }
                  Button(
                    onClick = {
                      viewModel.startConversationWithUser(found) { convId, peerUid ->
                        onOpenChat(convId, peerUid)
                      }
                    },
                    enabled = !searchState.isStartingChat,
                    shape = RoundedCornerShape(14.dp),
                    modifier =
                      Modifier.weight(1f)
                        .height(48.dp)
                        .testTag("start_chat_button"),
                  ) {
                    if (searchState.isStartingChat) {
                      CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp,
                      )
                    } else {
                      Icon(
                        Icons.AutoMirrored.Filled.Chat,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                      )
                      Spacer(modifier = Modifier.width(6.dp))
                      Text("Message")
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
