package com.example.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChatMessage
import com.example.data.model.ChatMessageUi
import com.example.data.model.EmojiCatalog
import com.example.data.model.MessageDeliveryStatus
import com.example.data.model.MessageType
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.IncomingBubbleDark
import com.example.ui.theme.IncomingBubbleLight
import com.example.ui.theme.OutgoingBubbleDark
import com.example.ui.theme.OutgoingBubbleLight
import com.example.ui.theme.PendingAmber
import com.example.ui.theme.ReadReceiptCyan
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatMessageBubble(
  item: ChatMessageUi,
  isMine: Boolean,
  peerName: String,
  onLongPress: (ChatMessage) -> Unit,
  onRetryFailed: (String) -> Unit,
  onReactionClick: (ChatMessage, String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val msg = item.message
  val messageType = MessageType.fromRaw(msg.messageType)
  val customEmoji =
    remember(msg.text, messageType) {
      if (messageType != MessageType.TEXT) EmojiCatalog.findByToken(msg.text) else null
    }
  val dark = isSystemInDarkTheme()
  val bubbleColor =
    if (isMine) {
      if (dark) OutgoingBubbleDark else OutgoingBubbleLight
    } else {
      if (dark) IncomingBubbleDark else IncomingBubbleLight
    }
  val contentColor = if (isMine) Color.White else MaterialTheme.colorScheme.onSurface

  val timeText =
    remember(msg.createdAt, msg.clientTimestampMs) {
      val millis =
        msg.createdAt?.toDate()?.time
          ?: msg.clientTimestampMs.takeIf { it > 0L }
          ?: System.currentTimeMillis()
      SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(millis))
    }

  val bubbleShape =
    if (isMine) {
      RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = 20.dp, bottomEnd = 6.dp)
    } else {
      RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = 6.dp, bottomEnd = 20.dp)
    }

  Column(
    modifier = modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp),
    horizontalAlignment = if (isMine) Alignment.End else Alignment.Start,
  ) {
    Surface(
      shape = bubbleShape,
      color = if (customEmoji != null) Color.Transparent else bubbleColor,
      tonalElevation = if (isMine || customEmoji != null) 0.dp else 1.dp,
      shadowElevation = if (customEmoji != null) 0.dp else 1.dp,
      modifier =
        Modifier.widthIn(max = 296.dp)
          .clip(bubbleShape)
          .combinedClickable(
            onClick = {
              if (item.status == MessageDeliveryStatus.FAILED) {
                onRetryFailed(msg.clientMessageId)
              }
            },
            onLongClick = { onLongPress(msg) },
          ),
    ) {
      Column(
        modifier =
          if (customEmoji != null) {
            Modifier.padding(4.dp)
          } else {
            Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
          }
      ) {
        if (!msg.replyToText.isNullOrBlank()) {
          val replyAuthor =
            if (msg.replyToSenderId == msg.senderId && isMine) "You"
            else if (msg.replyToSenderId != msg.senderId && !isMine) "You"
            else peerName
          Box(
            modifier =
              Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(
                  if (isMine) Color.White.copy(alpha = 0.16f)
                  else MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
                )
                .padding(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Column {
              Text(
                text = replyAuthor,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = if (isMine) ReadReceiptCyan else MaterialTheme.colorScheme.primary,
              )
              Text(
                text = msg.replyToText,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color =
                  if (isMine) Color.White.copy(alpha = 0.88f)
                  else MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
          Spacer(modifier = Modifier.height(6.dp))
        }

        if (customEmoji != null) {
          CrystalJellyEmojiView(emoji = customEmoji, size = 108.dp)
        } else {
          Text(
            text = msg.text,
            style = MaterialTheme.typography.bodyLarge,
            color = contentColor,
          )
        }

        Spacer(modifier = Modifier.height(3.dp))

        Row(
          modifier = Modifier.align(Alignment.End),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          Text(
            text = timeText,
            style = MaterialTheme.typography.labelSmall,
            fontSize = 10.5.sp,
            color =
              when {
                customEmoji != null -> MaterialTheme.colorScheme.onSurfaceVariant
                isMine -> Color.White.copy(alpha = 0.78f)
                else -> MaterialTheme.colorScheme.onSurfaceVariant
              },
          )
          if (isMine) {
            when (item.status) {
              MessageDeliveryStatus.SENDING -> {
                Icon(
                  imageVector = Icons.Default.Schedule,
                  contentDescription = "Sending message",
                  tint = if (customEmoji != null) PendingAmber else Color.White.copy(alpha = 0.85f),
                  modifier = Modifier.size(13.dp),
                )
              }
              MessageDeliveryStatus.SENT -> {
                Icon(
                  imageVector = Icons.Default.Done,
                  contentDescription = "Sent",
                  tint =
                    if (customEmoji != null) MaterialTheme.colorScheme.onSurfaceVariant
                    else Color.White.copy(alpha = 0.85f),
                  modifier = Modifier.size(14.dp),
                )
              }
              MessageDeliveryStatus.READ -> {
                Icon(
                  imageVector = Icons.Default.DoneAll,
                  contentDescription = "Read by recipient",
                  tint = ReadReceiptCyan,
                  modifier = Modifier.size(15.dp),
                )
              }
              MessageDeliveryStatus.FAILED -> {
                Icon(
                  imageVector = Icons.Default.ErrorOutline,
                  contentDescription = "Failed to send, tap to retry",
                  tint = ErrorRed,
                  modifier = Modifier.size(14.dp),
                )
              }
            }
          }
        }
      }
    }

    if (item.status == MessageDeliveryStatus.FAILED && isMine) {
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = "Failed • Tap bubble to retry",
        style = MaterialTheme.typography.labelSmall,
        color = ErrorRed,
        modifier = Modifier.padding(end = 6.dp),
      )
    }

    if (msg.reactions.isNotEmpty()) {
      Spacer(modifier = Modifier.height(2.dp))
      Row(
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier.padding(horizontal = 4.dp),
      ) {
        val grouped = msg.reactions.values.groupingBy { it }.eachCount()
        grouped.forEach { (emoji, count) ->
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            tonalElevation = 2.dp,
            onClick = { onReactionClick(msg, emoji) },
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(text = emoji, fontSize = 13.sp)
              if (count > 1) {
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                  text = count.toString(),
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
          }
        }
      }
    }
  }
}
