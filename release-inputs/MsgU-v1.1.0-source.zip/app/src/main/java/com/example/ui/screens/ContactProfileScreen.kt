package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.firebase.UserRepository
import com.example.data.firebase.toUserFriendlyFirestoreMessage
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.ui.components.MsgUAvatar
import com.example.ui.viewmodel.HomeViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactProfileScreen(
  peerUser: UserProfile,
  homeViewModel: HomeViewModel,
  userRepository: UserRepository,
  onBack: () -> Unit,
  onOpenChat: (conversationId: String, peerUid: String) -> Unit,
) {
  val contactsState by homeViewModel.contactsState.collectAsStateWithLifecycle()
  val contacts = (contactsState as? UiState.Success)?.data.orEmpty()
  val contactEntry = contacts.firstOrNull { it.contactUid == peerUser.userId }
  val isFavorite = contactEntry?.favorite == true
  val isBlocked = contactEntry?.blocked == true

  val scope = rememberCoroutineScope()
  var showReportDialog by remember { mutableStateOf(false) }
  var reportReason by remember { mutableStateOf("") }
  var statusMessage by remember { mutableStateOf<String?>(null) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Contact Profile") },
        navigationIcon = {
          IconButton(onClick = onBack, modifier = Modifier.testTag("contact_profile_back")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
      )
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      Column(
        modifier = Modifier.widthIn(max = 540.dp).fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        MsgUAvatar(
          displayName = peerUser.displayName,
          photoUrl = peerUser.photoUrl,
          size = 96.dp,
          showRing = true,
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
          text = peerUser.displayName,
          style = MaterialTheme.typography.headlineSmall,
          color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
          text = "@${peerUser.username}",
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.primary,
        )
        if (peerUser.bio.isNotBlank()) {
          Spacer(modifier = Modifier.height(10.dp))
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text(
              text = peerUser.bio,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.padding(16.dp),
            )
          }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
          onClick = {
            homeViewModel.startConversationWithUser(peerUser) { convId, peerUid ->
              onOpenChat(convId, peerUid)
            }
          },
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().height(52.dp).testTag("profile_message_button"),
        ) {
          Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("Send Message")
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          OutlinedButton(
            onClick = {
              scope.launch {
                userRepository
                  .setContactFavorite(peerUser, !isFavorite)
                  .onSuccess {
                    statusMessage =
                      if (!isFavorite) "Added to Favorites" else "Removed from Favorites"
                  }
                  .onFailure { statusMessage = it.toUserFriendlyFirestoreMessage() }
              }
            },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.weight(1f).height(48.dp).testTag("profile_favorite_button"),
          ) {
            Icon(
              imageVector = if (isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(if (isFavorite) "Favorited" else "Favorite")
          }

          OutlinedButton(
            onClick = {
              scope.launch {
                userRepository
                  .setContactBlocked(peerUser, !isBlocked)
                  .onSuccess {
                    statusMessage =
                      if (!isBlocked) "Blocked @${peerUser.username}"
                      else "Unblocked @${peerUser.username}"
                  }
                  .onFailure { statusMessage = it.toUserFriendlyFirestoreMessage() }
              }
            },
            shape = RoundedCornerShape(14.dp),
            colors =
              ButtonDefaults.outlinedButtonColors(
                contentColor =
                  if (isBlocked) MaterialTheme.colorScheme.primary
                  else MaterialTheme.colorScheme.error
              ),
            modifier = Modifier.weight(1f).height(48.dp).testTag("profile_block_button"),
          ) {
            Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(if (isBlocked) "Unblock" else "Block")
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        TextButton(
          onClick = { showReportDialog = true },
          modifier = Modifier.testTag("profile_report_button"),
        ) {
          Icon(
            Icons.Default.Flag,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text("Report User", color = MaterialTheme.colorScheme.error)
        }

        if (!statusMessage.isNullOrBlank()) {
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = statusMessage!!,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.primary,
          )
        }
      }
    }
  }

  if (showReportDialog) {
    AlertDialog(
      onDismissRequest = { showReportDialog = false },
      title = { Text("Report @${peerUser.username}") },
      text = {
        OutlinedTextField(
          value = reportReason,
          onValueChange = { reportReason = it.take(500) },
          label = { Text("Reason") },
          placeholder = { Text("Describe spam or abuse…") },
          maxLines = 4,
          modifier = Modifier.fillMaxWidth(),
        )
      },
      confirmButton = {
        Button(
          onClick = {
            val clean = reportReason.trim()
            if (clean.length >= 3) {
              scope.launch {
                userRepository
                  .submitReport(peerUser.userId, null, clean)
                  .onSuccess {
                    statusMessage = "Report submitted."
                    reportReason = ""
                    showReportDialog = false
                  }
                  .onFailure { statusMessage = it.toUserFriendlyFirestoreMessage() }
              }
            }
          },
          enabled = reportReason.trim().length >= 3,
        ) {
          Text("Submit Report")
        }
      },
      dismissButton = {
        TextButton(onClick = { showReportDialog = false }) { Text("Cancel") }
      },
    )
  }
}
