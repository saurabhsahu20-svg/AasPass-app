package com.example.ui.screens

import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.data.firebase.MsgUSettings
import com.example.data.firebase.signOutUser
import com.example.data.model.UserProfile
import com.example.ui.components.MsgUAvatar
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.ThemePreference

@Composable
fun SettingsScreen(
  currentProfile: UserProfile?,
  settings: MsgUSettings,
  hasNotificationPermission: Boolean,
  onRequestNotificationPermission: () -> Unit,
  onOpenSystemNotificationSettings: () -> Unit = {},
  onSendTestNotification: () -> Unit = {},
  onEditProfile: () -> Unit,
  onThemeSelected: (ThemePreference) -> Unit,
  onToggleNotifications: (Boolean) -> Unit,
  onToggleMessagePreviews: (Boolean) -> Unit,
  onToggleReadReceipts: (Boolean) -> Unit,
  onSignedOut: () -> Unit,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val credentialManager = remember(context) { CredentialManager.create(context) }

  Column(
    modifier =
      Modifier.fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    // Current User Profile Card
    Card(
      shape = RoundedCornerShape(22.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Row(
        modifier = Modifier.padding(18.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        MsgUAvatar(
          displayName = currentProfile?.displayName ?: "MsgU User",
          photoUrl = currentProfile?.photoUrl.orEmpty(),
          size = 62.dp,
          showRing = true,
        )
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = currentProfile?.displayName ?: "MsgU User",
            style = MaterialTheme.typography.titleLarge,
          )
          if (currentProfile != null) {
            Text(
              text = "@${currentProfile.username}",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.primary,
            )
            if (currentProfile.bio.isNotBlank()) {
              Text(
                text = currentProfile.bio,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }
        OutlinedButton(
          onClick = onEditProfile,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.testTag("settings_edit_profile"),
        ) {
          Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Edit")
        }
      }
    }

    // Notifications Card
    Card(
      shape = RoundedCornerShape(22.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(
        modifier = Modifier.padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            Icons.Default.Notifications,
            contentDescription = null,
            tint = if (hasNotificationPermission && settings.notificationsEnabled) ErrorRed else MaterialTheme.colorScheme.primary,
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text("Notifications", style = MaterialTheme.typography.titleMedium)
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text("Message Alerts", style = MaterialTheme.typography.bodyLarge)
            Text(
              if (hasNotificationPermission) "Alerts and red unread badges are active."
              else "System notification permission is off.",
              style = MaterialTheme.typography.bodySmall,
              color = if (hasNotificationPermission) MaterialTheme.colorScheme.onSurfaceVariant else ErrorRed,
            )
          }
          Switch(
            checked = settings.notificationsEnabled && hasNotificationPermission,
            onCheckedChange = { checked ->
              if (checked && !hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                onRequestNotificationPermission()
              } else {
                onToggleNotifications(checked)
              }
            },
            modifier = Modifier.testTag("notifications_switch"),
          )
        }

        if (!hasNotificationPermission) {
          Button(
            onClick = onRequestNotificationPermission,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
            modifier = Modifier.fillMaxWidth().testTag("grant_notification_permission"),
          ) {
            Text("Enable Android Notifications")
          }
          OutlinedButton(
            onClick = onOpenSystemNotificationSettings,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().testTag("open_system_notification_settings"),
          ) {
            Text("Open Phone Notification Settings")
          }
        } else {
          OutlinedButton(
            onClick = onSendTestNotification,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().testTag("send_test_notification"),
          ) {
            Text("Send Test Notification")
          }
        }
      }
    }

    // Appearance Card
    Card(
      shape = RoundedCornerShape(22.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(modifier = Modifier.padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            Icons.Default.Palette,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text("Appearance", style = MaterialTheme.typography.titleMedium)
        }
        Spacer(modifier = Modifier.height(12.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          ThemePreference.entries.forEach { option ->
            FilterChip(
              selected = settings.themePreference == option,
              onClick = { onThemeSelected(option) },
              label = {
                Text(
                  when (option) {
                    ThemePreference.SYSTEM -> "System"
                    ThemePreference.LIGHT -> "Light"
                    ThemePreference.DARK -> "Dark"
                  }
                )
              },
              modifier = Modifier.testTag("theme_${option.name.lowercase()}"),
            )
          }
        }
      }
    }

    // Privacy & Receipts Card
    Card(
      shape = RoundedCornerShape(22.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(
        modifier = Modifier.padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            Icons.Default.Security,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text("Privacy & Messaging", style = MaterialTheme.typography.titleMedium)
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text("Chat List Message Previews", style = MaterialTheme.typography.bodyLarge)
            Text(
              "Show unread message snippets on the Chats screen and notifications.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
          Switch(
            checked = settings.showMessagePreviews,
            onCheckedChange = onToggleMessagePreviews,
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text("Send Read Receipts", style = MaterialTheme.typography.bodyLarge)
            Text(
              "Let contacts see when you have opened and read their messages.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
          Switch(
            checked = settings.sendReadReceipts,
            onCheckedChange = onToggleReadReceipts,
          )
        }
      }
    }

    // Real-Time Sync Info Card
    Card(
      shape = RoundedCornerShape(22.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Row(
        modifier = Modifier.padding(18.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Icon(
          Icons.Default.CloudDone,
          contentDescription = null,
          tint = SuccessGreen,
          modifier = Modifier.size(26.dp),
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            "Cloud Firestore Real-Time Sync",
            style = MaterialTheme.typography.titleSmall,
          )
          Text(
            "Offline cache & pending write queue active. Messages sync automatically on reconnect.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
    }

    Button(
      onClick = {
        signOutUser(
          credentialManager = credentialManager,
          scope = scope,
          onSignOutComplete = onSignedOut,
        )
      },
      shape = RoundedCornerShape(16.dp),
      colors =
        ButtonDefaults.buttonColors(
          containerColor = MaterialTheme.colorScheme.error,
          contentColor = MaterialTheme.colorScheme.onError,
        ),
      modifier = Modifier.fillMaxWidth().height(52.dp).testTag("sign_out_button"),
    ) {
      Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
      Spacer(modifier = Modifier.width(8.dp))
      Text("Sign Out")
    }
  }
}
