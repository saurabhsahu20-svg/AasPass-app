package com.example.notifications

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R

object MsgUNotificationHelper {
  const val CHANNEL_ID = "msgu_messages_v2"
  const val EXTRA_CONVERSATION_ID = "extra_conversation_id"
  const val EXTRA_PEER_UID = "extra_peer_uid"
  private const val RED_ACCENT = 0xFFEF4444.toInt()
  private const val TEST_NOTIFICATION_ID = 900900

  fun ensureNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val manager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
      val existing = manager.getNotificationChannel(CHANNEL_ID)
      if (existing == null) {
        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val audioAttributes =
          AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION_COMMUNICATION_INSTANT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val channel =
          NotificationChannel(
              CHANNEL_ID,
              "MsgU Messages",
              NotificationManager.IMPORTANCE_HIGH,
            )
            .apply {
              description = "Instant incoming message alerts with sound and red badge"
              enableLights(true)
              lightColor = RED_ACCENT
              enableVibration(true)
              vibrationPattern = longArrayOf(0L, 160L, 80L, 160L)
              setSound(soundUri, audioAttributes)
              lockscreenVisibility = Notification.VISIBILITY_PUBLIC
              setShowBadge(true)
            }
        manager.createNotificationChannel(channel)
      }
    }
  }

  fun hasNotificationPermission(context: Context): Boolean {
    val runtimeGranted =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
          PackageManager.PERMISSION_GRANTED
      } else {
        true
      }
    return runtimeGranted && NotificationManagerCompat.from(context).areNotificationsEnabled()
  }

  fun openAppNotificationSettings(context: Context) {
    val intent =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
          putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        }
      } else {
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
          data = Uri.fromParts("package", context.packageName, null)
        }
      }
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
      context.startActivity(intent)
    } catch (_: Exception) {
      val fallback =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
          data = Uri.fromParts("package", context.packageName, null)
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
      try {
        context.startActivity(fallback)
      } catch (_: Exception) {
        // Ignore if settings activity unavailable
      }
    }
  }

  fun showIncomingMessageNotification(
    context: Context,
    conversationId: String,
    peerUid: String,
    senderName: String,
    messagePreview: String,
    unreadCount: Int,
    showPreview: Boolean,
  ) {
    if (!hasNotificationPermission(context)) return
    ensureNotificationChannel(context)

    val tapIntent =
      Intent(context, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        putExtra(EXTRA_CONVERSATION_ID, conversationId)
        putExtra(EXTRA_PEER_UID, peerUid)
      }
    val pendingIntent =
      PendingIntent.getActivity(
        context,
        conversationId.hashCode(),
        tapIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )

    val body =
      if (showPreview && messagePreview.isNotBlank()) messagePreview
      else "New message ($unreadCount unread)"

    val notification =
      NotificationCompat.Builder(context, CHANNEL_ID)
        .setSmallIcon(R.drawable.ic_stat_msgu)
        .setColor(RED_ACCENT)
        .setColorized(false)
        .setContentTitle(senderName)
        .setContentText(body)
        .setStyle(NotificationCompat.BigTextStyle().bigText(body))
        .setPriority(NotificationCompat.PRIORITY_MAX)
        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        .setDefaults(NotificationCompat.DEFAULT_ALL)
        .setVibrate(longArrayOf(0L, 160L, 80L, 160L))
        .setNumber(unreadCount.coerceAtLeast(1))
        .setOnlyAlertOnce(false)
        .setAutoCancel(true)
        .setContentIntent(pendingIntent)
        .build()

    try {
      NotificationManagerCompat.from(context).notify(conversationId.hashCode(), notification)
    } catch (_: SecurityException) {
      // Permission revoked concurrently
    }
  }

  fun showTestNotification(context: Context): Boolean {
    if (!hasNotificationPermission(context)) return false
    ensureNotificationChannel(context)
    val tapIntent =
      Intent(context, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
      }
    val pendingIntent =
      PendingIntent.getActivity(
        context,
        TEST_NOTIFICATION_ID,
        tapIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )
    val notification =
      NotificationCompat.Builder(context, CHANNEL_ID)
        .setSmallIcon(R.drawable.ic_stat_msgu)
        .setColor(RED_ACCENT)
        .setContentTitle("MsgU Notifications Active")
        .setContentText("Real-time message alerts, sound, and red badges are working!")
        .setPriority(NotificationCompat.PRIORITY_MAX)
        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
        .setDefaults(NotificationCompat.DEFAULT_ALL)
        .setAutoCancel(true)
        .setContentIntent(pendingIntent)
        .build()
    return try {
      NotificationManagerCompat.from(context).notify(TEST_NOTIFICATION_ID, notification)
      true
    } catch (_: SecurityException) {
      false
    }
  }

  fun cancelConversationNotification(context: Context, conversationId: String) {
    NotificationManagerCompat.from(context).cancel(conversationId.hashCode())
  }
}
