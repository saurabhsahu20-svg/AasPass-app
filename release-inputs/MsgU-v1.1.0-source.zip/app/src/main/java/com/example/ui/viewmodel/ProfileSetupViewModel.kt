package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.UserRepository
import com.example.data.firebase.toUserFriendlyFirestoreMessage
import com.example.data.model.UserProfile
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ProfileSetupUiState(
  val usernameInput: String = "",
  val displayNameInput: String = "",
  val bioInput: String = "",
  val photoUrl: String = "",
  val isCheckingUsername: Boolean = false,
  val isUsernameAvailable: Boolean? = null,
  val usernameValidationError: String? = null,
  val isSaving: Boolean = false,
  val errorMessage: String? = null,
  val savedSuccess: Boolean = false,
)

class ProfileSetupViewModel(
  private val userRepository: UserRepository,
  private val currentUserId: String,
  initialDisplayName: String,
  initialPhotoUrl: String,
  existingProfile: UserProfile? = null,
) : ViewModel() {

  private val suggestedUsername =
    existingProfile?.username?.takeIf { it.isNotBlank() }
      ?: initialDisplayName
        .lowercase()
        .replace(Regex("[^a-z0-9_]"), "_")
        .replace(Regex("_+"), "_")
        .trim('_')
        .take(18)
        .let { base ->
          if (base.length >= 3) base else "msgu_${currentUserId.take(6).lowercase()}"
        }

  private val _uiState =
    MutableStateFlow(
      ProfileSetupUiState(
        usernameInput = suggestedUsername,
        displayNameInput = existingProfile?.displayName?.ifBlank { initialDisplayName }
          ?: initialDisplayName.ifBlank { "MsgU User" },
        bioInput = existingProfile?.bio.orEmpty(),
        photoUrl = existingProfile?.photoUrl?.ifBlank { initialPhotoUrl } ?: initialPhotoUrl,
        isUsernameAvailable = if (existingProfile != null) true else null,
      )
    )
  val uiState: StateFlow<ProfileSetupUiState> = _uiState.asStateFlow()

  private var checkJob: Job? = null

  init {
    if (existingProfile == null) {
      checkAvailabilityDebounced(suggestedUsername)
    }
  }

  fun onUsernameChanged(raw: String) {
    val sanitized = raw.lowercase().replace(" ", "").removePrefix("@").take(24)
    val formatError =
      when {
        sanitized.isEmpty() -> "Username is required."
        !UserRepository.USERNAME_REGEX.matches(sanitized) ->
          "Use 3–24 lowercase letters, numbers, or underscores."
        else -> null
      }
    _uiState.update {
      it.copy(
        usernameInput = sanitized,
        usernameValidationError = formatError,
        isUsernameAvailable = null,
        errorMessage = null,
      )
    }
    if (formatError == null) {
      checkAvailabilityDebounced(sanitized)
    } else {
      checkJob?.cancel()
    }
  }

  fun onDisplayNameChanged(value: String) {
    _uiState.update { it.copy(displayNameInput = value.take(50), errorMessage = null) }
  }

  fun onBioChanged(value: String) {
    _uiState.update { it.copy(bioInput = value.take(160), errorMessage = null) }
  }

  private fun checkAvailabilityDebounced(username: String) {
    checkJob?.cancel()
    checkJob =
      viewModelScope.launch {
        _uiState.update { it.copy(isCheckingUsername = true) }
        delay(350L)
        try {
          val result = userRepository.checkUsernameAvailable(username)
          _uiState.update { state ->
            if (state.usernameInput != username) return@update state
            result.fold(
              onSuccess = { available ->
                state.copy(
                  isCheckingUsername = false,
                  isUsernameAvailable = available,
                  usernameValidationError =
                    if (!available) "@$username is already taken." else null,
                )
              },
              onFailure = {
                state.copy(isCheckingUsername = false, isUsernameAvailable = null)
              },
            )
          }
        } catch (e: CancellationException) {
          throw e
        }
      }
  }

  fun saveProfile() {
    val state = _uiState.value
    val username = state.usernameInput.trim().lowercase()
    val displayName = state.displayNameInput.trim()
    if (!UserRepository.USERNAME_REGEX.matches(username)) {
      _uiState.update {
        it.copy(usernameValidationError = "Use 3–24 lowercase letters, numbers, or underscores.")
      }
      return
    }
    if (displayName.isBlank()) {
      _uiState.update { it.copy(errorMessage = "Please enter a display name.") }
      return
    }
    if (state.isSaving) return

    viewModelScope.launch {
      _uiState.update { it.copy(isSaving = true, errorMessage = null) }
      val result =
        userRepository.saveUserProfile(
          username = username,
          displayName = displayName,
          bio = state.bioInput,
          photoUrl = state.photoUrl,
        )
      result.fold(
        onSuccess = {
          _uiState.update { it.copy(isSaving = false, savedSuccess = true) }
        },
        onFailure = { err ->
          _uiState.update {
            it.copy(isSaving = false, errorMessage = err.toUserFriendlyFirestoreMessage())
          }
        },
      )
    }
  }
}
