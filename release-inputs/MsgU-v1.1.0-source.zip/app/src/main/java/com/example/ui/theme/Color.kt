package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// MsgU Electric Cobalt & Luminous Cyan Brand Palette
val CobaltPrimaryLight = Color(0xFF0B63F6)
val OnCobaltPrimaryLight = Color(0xFFFFFFFF)
val CobaltContainerLight = Color(0xFFDBE8FF)
val OnCobaltContainerLight = Color(0xFF001B4D)

val CyanSecondaryLight = Color(0xFF0096C7)
val OnCyanSecondaryLight = Color(0xFFFFFFFF)
val CyanContainerLight = Color(0xFFCFF4FF)
val OnCyanContainerLight = Color(0xFF002636)

val TealTertiaryLight = Color(0xFF0EA5E9)
val BackgroundLight = Color(0xFFF6F9FC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEAF1F8)
val OnSurfaceLight = Color(0xFF0F172A)
val OnSurfaceVariantLight = Color(0xFF52637A)
val OutlineLight = Color(0xFFCBD5E1)

// Dark Theme Tokens
val SkyPrimaryDark = Color(0xFF38BDF8)
val OnSkyPrimaryDark = Color(0xFF002236)
val CobaltContainerDark = Color(0xFF143A7B)
val OnCobaltContainerDark = Color(0xFFD6E6FF)

val CyanSecondaryDark = Color(0xFF22D3EE)
val OnCyanSecondaryDark = Color(0xFF002933)
val CyanContainerDark = Color(0xFF083A4E)
val OnCyanContainerDark = Color(0xFFCFF4FF)

val TealTertiaryDark = Color(0xFF60A5FA)
val BackgroundDark = Color(0xFF080D18)
val SurfaceDark = Color(0xFF101827)
val SurfaceVariantDark = Color(0xFF1A253A)
val OnSurfaceDark = Color(0xFFF1F5F9)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF2B3952)

// Semantic Messaging Accents
val OutgoingBubbleLight = Color(0xFF0B63F6)
val OutgoingBubbleDark = Color(0xFF1D4ED8)
val IncomingBubbleLight = Color(0xFFFFFFFF)
val IncomingBubbleDark = Color(0xFF1A253A)
val ReadReceiptCyan = Color(0xFF22D3EE)
val ErrorRed = Color(0xFFEF4444)
val SuccessGreen = Color(0xFF10B981)
val PendingAmber = Color(0xFFF59E0B)
