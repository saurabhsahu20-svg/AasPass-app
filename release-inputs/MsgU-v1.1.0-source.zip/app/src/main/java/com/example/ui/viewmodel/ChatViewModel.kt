package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.ChatRepository
import com.example.data.firebase.PreferencesRepository
import com.example.data.firebase.UserRepository
import com.example.data.firebase.toUserFriendlyFirestoreMessage
import com.example.data.model.ChatMessage
import com.example.data.model.ChatMessageUi
import com.example.data.model.Conversation
import com.example.data.model.FailedOutboundMessage
import com.example.data.model.MessageDeliveryStatus
import com.example.data.model.MessageType
import com.example.data.model.ReplyTarget
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.google.firebase.firestore.FirebaseFirestoreException
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChatViewModel(
  private val chatRepository: ChatRepository,
  private val userRepository: UserRepository,
  private val preferencesRepository: PreferencesRepository,
  val conversationId: String,
  val currentUserId: String,
  val peerUserId: String,
  initialCurrentProfile: UserProfile? = null,
) : ViewModel() {

  val conversationState: StateFlow<UiState<Conversation?>> =
    chatRepository
      .observeConversation(conversationId)
      .map<Conversation?, UiState<Conversation?>> { UiState.Success(it) }
      .catch { error ->
        val firestoreError =
          generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, "Error observing conversation", rootError)
        emit(UiState.Error(rootError.toUserFriendlyFirestoreMessage()))
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
        initialValue = UiState.Loading,
      )

  // Live peer profile observation for instant Online / Last Seen & profile updates
  val peerProfile: StateFlow<UserProfile?> =
    userRepository
      .observeUserProfile(peerUserId)
      .catch { error ->
        val firestoreError =
          generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        emit(null)
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
        initialValue = null,
      )

  // 0ms optimistic outgoing messages so bubbles render instantaneously on tap before Firestore snapshot echoes
  private val _optimisticMessages = MutableStateFlow<List<ChatMessageUi>>(emptyList())
  private val _failedMessages = MutableStateFlow<List<FailedOutboundMessage>>(emptyList())

  val messagesState: StateFlow<UiState<List<ChatMessageUi>>> =
    combine(
        chatRepository.observeMessages(conversationId, currentUserId),
        _optimisticMessages,
        _failedMessages,
      ) { serverMessages, optimistic, failed ->
        val serverIds = serverMessages.mapTo(HashSet()) { it.message.clientMessageId }
        val failedIds = failed.mapTo(HashSet()) { it.clientMessageId }
        val pendingOptimistic =
          optimistic.filter {
            it.message.clientMessageId !in serverIds && it.message.clientMessageId !in failedIds
          }
        val failedUi =
          failed
            .filter { it.clientMessageId !in serverIds }
            .map { item ->
              ChatMessageUi(
                message =
                  ChatMessage(
                    id = item.clientMessageId,
                    conversationId = conversationId,
                    participantUids = listOf(currentUserId, peerUserId).sorted(),
                    senderId = currentUserId,
                    text = item.text,
                    messageType = item.messageType.name,
                    clientMessageId = item.clientMessageId,
                    clientTimestampMs = item.clientTimestampMs,
                    readBy = listOf(currentUserId),
                    replyToMessageId = item.replyTo?.messageId,
                    replyToText = item.replyTo?.previewText,
                    replyToSenderId = item.replyTo?.senderId,
                  ),
                status = MessageDeliveryStatus.FAILED,
              )
            }
        UiState.Success(
          (serverMessages + pendingOptimistic + failedUi).sortedWith(
            compareBy<ChatMessageUi>(
              { it.message.createdAt?.seconds ?: (it.message.clientTimestampMs / 1000L) },
              { it.message.createdAt?.nanoseconds ?: 0 },
              { it.message.clientTimestampMs },
            )
          )
        ) as UiState<List<ChatMessageUi>>
      }
      .catch { error ->
        val firestoreError =
          generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, "Error observing messages", rootError)
        emit(UiState.Error(rootError.toUserFriendlyFirestoreMessage()))
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
        initialValue = UiState.Loading,
      )

  val isPeerBlocked: StateFlow<Boolean> =
    userRepository
      .observeContacts(currentUserId)
      .map { contacts -> contacts.firstOrNull { it.contactUid == peerUserId }?.blocked == true }
      .catch { error ->
        val firestoreError =
          generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        emit(false)
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
        initialValue = false,
      )

  val isPeerFavorite: StateFlow<Boolean> =
    userRepository
      .observeContacts(currentUserId)
      .map { contacts -> contacts.firstOrNull { it.contactUid == peerUserId }?.favorite == true }
      .catch { error ->
        val firestoreError =
          generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        emit(false)
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
        initialValue = false,
      )

  val recentEmojis: StateFlow<List<String>> =
    preferencesRepository.settingsFlow
      .map { it.recentEmojis }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
        initialValue = emptyList(),
      )

  val favoriteEmojis: StateFlow<List<String>> =
    preferencesRepository.settingsFlow
      .map { it.favoriteEmojis }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
        initialValue = emptyList(),
      )

  private val _currentUserProfile = MutableStateFlow(initialCurrentProfile)
  val currentUserProfile: StateFlow<UserProfile?> = _currentUserProfile.asStateFlow()

  private val _draftText = MutableStateFlow("")
  val draftText: StateFlow<String> = _draftText.asStateFlow()

  private val _replyTarget = MutableStateFlow<ReplyTarget?>(null)
  val replyTarget: StateFlow<ReplyTarget?> = _replyTarget.asStateFlow()

  private val _actionError = MutableStateFlow<String?>(null)
  val actionError: StateFlow<String?> = _actionError.asStateFlow()

  private val _actionFeedback = MutableStateFlow<String?>(null)
  val actionFeedback: StateFlow<String?> = _actionFeedback.asStateFlow()

  private var typingResetJob: Job? = null
  private var isCurrentlyTypingSent = false
  private var lastTypingWriteMs = 0L

  init {
    if (_currentUserProfile.value == null) {
      viewModelScope.launch {
        userRepository.getUserProfile(currentUserId).onSuccess { _currentUserProfile.value = it }
      }
    }
  }

  fun onDraftChanged(newText: String) {
    if (newText.length <= 2000) {
      _draftText.value = newText
      handleTypingSignal(newText.isNotBlank())
    }
  }

  private fun handleTypingSignal(hasText: Boolean) {
    val convReady = (conversationState.value as? UiState.Success)?.data != null
    if (!convReady) return
    val now = System.currentTimeMillis()
    if (hasText) {
      if (!isCurrentlyTypingSent || (now - lastTypingWriteMs) > 4_000L) {
        isCurrentlyTypingSent = true
        lastTypingWriteMs = now
        viewModelScope.launch {
          chatRepository.setTypingStatus(conversationId, currentUserId, isTyping = true)
        }
      }
      typingResetJob?.cancel()
      typingResetJob =
        viewModelScope.launch {
          delay(3_200L)
          if (isCurrentlyTypingSent) {
            isCurrentlyTypingSent = false
            chatRepository.setTypingStatus(conversationId, currentUserId, isTyping = false)
          }
        }
    } else if (isCurrentlyTypingSent) {
      typingResetJob?.cancel()
      isCurrentlyTypingSent = false
      viewModelScope.launch {
        chatRepository.setTypingStatus(conversationId, currentUserId, isTyping = false)
      }
    }
  }

  fun appendEmojiToDraft(emoji: String) {
    val updated = _draftText.value + emoji
    if (updated.length <= 2000) {
      _draftText.value = updated
      handleTypingSignal(true)
    }
    viewModelScope.launch { preferencesRepository.recordRecentEmoji(emoji) }
  }

  fun setReplyTarget(target: ReplyTarget?) {
    _replyTarget.value = target
  }

  fun sendTextMessage() {
    val text = _draftText.value.trim()
    if (text.isEmpty()) return
    if (isPeerBlocked.value) {
      _actionError.value = "You blocked this contact. Unblock them to send messages."
      return
    }
    _draftText.value = ""
    typingResetJob?.cancel()
    isCurrentlyTypingSent = false
    val reply = _replyTarget.value
    _replyTarget.value = null
    sendInternal(text = text, messageType = MessageType.TEXT, replyTo = reply)
  }

  fun sendCustomEmoji(token: String, messageType: MessageType) {
    typingResetJob?.cancel()
    isCurrentlyTypingSent = false
    val reply = _replyTarget.value
    _replyTarget.value = null
    viewModelScope.launch { preferencesRepository.recordRecentEmoji(token) }
    sendInternal(text = token, messageType = messageType, replyTo = reply)
  }

  fun toggleFavoriteEmoji(tokenOrGlyph: String) {
    viewModelScope.launch { preferencesRepository.toggleFavoriteEmoji(tokenOrGlyph) }
  }

  fun retryFailedMessage(failedId: String) {
    val item = _failedMessages.value.firstOrNull { it.clientMessageId == failedId } ?: return
    _failedMessages.update { list -> list.filterNot { it.clientMessageId == failedId } }
    sendInternal(
      text = item.text,
      messageType = item.messageType,
      replyTo = item.replyTo,
      existingClientMessageId = item.clientMessageId,
      existingTimestampMs = item.clientTimestampMs,
      isRetry = true,
    )
  }

  private fun sendInternal(
    text: String,
    messageType: MessageType,
    replyTo: ReplyTarget?,
    existingClientMessageId: String? = null,
    existingTimestampMs: Long? = null,
    isRetry: Boolean = false,
  ) {
    if (isPeerBlocked.value) {
      _actionError.value = "You blocked this contact. Unblock them to send messages."
      return
    }
    val clientMessageId = existingClientMessageId ?: UUID.randomUUID().toString().replace("-", "")
    val clientTs = existingTimestampMs ?: System.currentTimeMillis()

    // Instant 0ms optimistic bubble insertion BEFORE network roundtrip
    val optimisticUi =
      ChatMessageUi(
        message =
          ChatMessage(
            id = clientMessageId,
            conversationId = conversationId,
            participantUids = listOf(currentUserId, peerUserId).sorted(),
            senderId = currentUserId,
            text = text,
            messageType = messageType.name,
            clientMessageId = clientMessageId,
            clientTimestampMs = clientTs,
            readBy = listOf(currentUserId),
            replyToMessageId = replyTo?.messageId,
            replyToText = replyTo?.previewText,
            replyToSenderId = replyTo?.senderId,
          ),
        status = MessageDeliveryStatus.SENDING,
        isFromCache = true,
      )
    _optimisticMessages.update { list ->
      list.filterNot { it.message.clientMessageId == clientMessageId } + optimisticUi
    }

    viewModelScope.launch {
      val me =
        _currentUserProfile.value
          ?: userRepository.getUserProfile(currentUserId).getOrNull()
      val peer =
        peerProfile.value
          ?: conversationToFallbackPeerProfile()
          ?: userRepository.getUserProfile(peerUserId).getOrNull()

      if (me == null || peer == null) {
        _optimisticMessages.update { list ->
          list.filterNot { it.message.clientMessageId == clientMessageId }
        }
        val msg = "Unable to verify participant profiles."
        _failedMessages.update {
          it + FailedOutboundMessage(clientMessageId, text, messageType, clientTs, replyTo, msg)
        }
        _actionError.value = msg
        return@launch
      }

      val convExists = (conversationState.value as? UiState.Success)?.data != null
      val result =
        chatRepository.sendMessage(
          conversationId = conversationId,
          currentUser = me,
          peerUser = peer,
          text = text,
          messageType = messageType,
          clientMessageId = clientMessageId,
          clientTimestampMs = clientTs,
          replyTo = replyTo,
          conversationAlreadyExists = convExists,
          isRetry = isRetry,
        )
      _optimisticMessages.update { list ->
        list.filterNot { it.message.clientMessageId == clientMessageId }
      }
      result.onFailure { err ->
        val friendly = err.toUserFriendlyFirestoreMessage()
        _failedMessages.update {
          it +
            FailedOutboundMessage(
              clientMessageId = clientMessageId,
              text = text,
              messageType = messageType,
              clientTimestampMs = clientTs,
              replyTo = replyTo,
              errorMessage = friendly,
            )
        }
        _actionError.value = friendly
      }
    }
  }

  private fun conversationToFallbackPeerProfile(): UserProfile? {
    val conv = (conversationState.value as? UiState.Success)?.data ?: return null
    val peerUid = conv.peerUid(currentUserId)
    if (peerUid.isBlank()) return null
    return UserProfile(
      userId = peerUid,
      username = conv.peerUsername(currentUserId),
      displayName = conv.peerDisplayName(currentUserId),
      photoUrl = conv.peerPhotoUrl(currentUserId),
    )
  }

  private val markedMessageIds = mutableSetOf<String>()

  fun markVisibleMessagesRead(messages: List<ChatMessageUi>, conversationUnreadCount: Long) {
    val unreadCandidates =
      messages
        .map { it.message }
        .filter {
          it.senderId != currentUserId &&
            !it.readBy.contains(currentUserId) &&
            it.id.isNotBlank() &&
            it.id !in markedMessageIds
        }
    if (unreadCandidates.isEmpty() && conversationUnreadCount <= 0L) return

    unreadCandidates.forEach { markedMessageIds.add(it.id) }
    viewModelScope.launch {
      val settings = preferencesRepository.settingsFlow.first()
      if (!settings.sendReadReceipts && conversationUnreadCount <= 0L) return@launch
      val toMark = if (settings.sendReadReceipts) unreadCandidates else emptyList()
      val res =
        chatRepository.markMessagesAsRead(
          conversationId = conversationId,
          currentUserId = currentUserId,
          unreadMessages = toMark,
          conversationUnreadCount = conversationUnreadCount,
        )
      if (res.isFailure) {
        unreadCandidates.forEach { markedMessageIds.remove(it.id) }
      }
    }
  }

  fun toggleReaction(message: ChatMessage, emoji: String) {
    if (message.id.isBlank()) return
    viewModelScope.launch {
      chatRepository
        .toggleReaction(
          conversationId = conversationId,
          messageId = message.id,
          currentUserId = currentUserId,
          emoji = emoji,
        )
        .onFailure { _actionError.value = it.toUserFriendlyFirestoreMessage() }
    }
  }

  fun toggleFavorite() {
    viewModelScope.launch {
      val peer = peerProfile.value ?: conversationToFallbackPeerProfile() ?: return@launch
      val next = !isPeerFavorite.value
      userRepository
        .setContactFavorite(peer, next)
        .onSuccess {
          _actionFeedback.value = if (next) "Added to Favorites" else "Removed from Favorites"
        }
        .onFailure { _actionError.value = it.toUserFriendlyFirestoreMessage() }
    }
  }

  fun toggleBlocked() {
    viewModelScope.launch {
      val peer = peerProfile.value ?: conversationToFallbackPeerProfile() ?: return@launch
      val next = !isPeerBlocked.value
      userRepository
        .setContactBlocked(peer, next)
        .onSuccess {
          _actionFeedback.value =
            if (next) "Blocked ${peer.displayName}" else "Unblocked ${peer.displayName}"
        }
        .onFailure { _actionError.value = it.toUserFriendlyFirestoreMessage() }
    }
  }

  fun reportPeer(reason: String) {
    viewModelScope.launch {
      userRepository
        .submitReport(reportedUid = peerUserId, conversationId = conversationId, reason = reason)
        .onSuccess { _actionFeedback.value = "Report submitted. Thank you for keeping MsgU safe." }
        .onFailure { _actionError.value = it.toUserFriendlyFirestoreMessage() }
    }
  }

  fun clearMessages() {
    _actionError.value = null
    _actionFeedback.value = null
  }

  override fun onCleared() {
    super.onCleared()
    if (isCurrentlyTypingSent) {
      isCurrentlyTypingSent = false
      // Best-effort clear typing flag on exit
      kotlinx.coroutines.CoroutineScope(NonCancellable).launch {
        chatRepository.setTypingStatus(conversationId, currentUserId, isTyping = false)
      }
    }
  }

  private companion object {
    const val TAG = "ChatVM"
    const val STOP_TIMEOUT_MS = 5000L
  }
}
