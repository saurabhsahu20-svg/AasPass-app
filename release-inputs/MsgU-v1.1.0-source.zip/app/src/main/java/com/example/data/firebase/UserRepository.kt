package com.example.data.firebase

import com.example.data.model.ContactEntry
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class UserRepository(
  private val db: FirebaseFirestore,
  private val auth: FirebaseAuth = Firebase.auth,
) {
  companion object {
    val USERNAME_REGEX = Regex("^[a-z0-9_]{3,24}$")
  }

  private fun requireUserId(): String =
    auth.currentUser?.uid
      ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")

  fun observeCurrentUserProfile(uid: String): Flow<UserProfile?> = flow {
    val currentUid = requireUserId()
    check(currentUid == uid) { "Authenticated user mismatch" }
    val docRef = db.collection("users").document(uid)
    emitAll(
      docRef
        .snapshots()
        .map { snapshot ->
          if (snapshot.exists()) {
            snapshot.toObject(UserProfile::class.java, ServerTimestampBehavior.ESTIMATE)
          } else {
            null
          }
        }
        .catch { error ->
          val firestoreError =
            generateSequence(error) { it.cause }
              .filterIsInstance<com.google.firebase.firestore.FirebaseFirestoreException>()
              .firstOrNull()
          if (firestoreError == null && error is CancellationException) throw error
          val ex = firestoreError ?: (error as? Exception)
          if (ex != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(ex, OperationType.GET, docRef.path)
          }
          throw error
        }
    )
  }

  fun observeUserProfile(targetUid: String): Flow<UserProfile?> = flow {
    val currentUid = requireUserId()
    require(targetUid.isNotBlank()) { "Target UID must not be blank" }
    val docRef = db.collection("users").document(targetUid)
    emitAll(
      docRef
        .snapshots()
        .map { snapshot ->
          if (snapshot.exists()) {
            snapshot.toObject(UserProfile::class.java, ServerTimestampBehavior.ESTIMATE)
          } else {
            null
          }
        }
        .catch { error ->
          val firestoreError =
            generateSequence(error) { it.cause }
              .filterIsInstance<com.google.firebase.firestore.FirebaseFirestoreException>()
              .firstOrNull()
          if (firestoreError == null && error is CancellationException) throw error
          val ex = firestoreError ?: (error as? Exception)
          if (ex != null && auth.currentUser?.uid == currentUid) {
            handleFirestoreError(ex, OperationType.GET, docRef.path)
          }
          throw error
        }
    )
  }

  suspend fun updatePresence(uid: String): Result<Unit> {
    val path = "users/$uid"
    return try {
      val currentUid = requireUserId()
      if (currentUid != uid) return Result.success(Unit)
      db.collection("users")
        .document(uid)
        .update(
          mapOf(
            "lastActiveAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        )
        .await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      // Presence is best-effort; profile might not be created yet on initial onboarding.
      Result.failure(e)
    }
  }

  suspend fun getUserProfile(uid: String): Result<UserProfile?> {
    val path = "users/$uid"
    return try {
      requireUserId()
      require(uid.isNotBlank()) { "User ID must not be blank" }
      val snap = db.collection("users").document(uid).get().await()
      val profile =
        if (snap.exists()) {
          snap.toObject(UserProfile::class.java, ServerTimestampBehavior.ESTIMATE)
        } else {
          null
        }
      Result.success(profile)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.GET, path)
      Result.failure(e)
    }
  }

  suspend fun searchByExactUsername(rawQuery: String): Result<UserProfile?> {
    val normalized = rawQuery.trim().lowercase().removePrefix("@")
    val path = "usernames/$normalized"
    return try {
      requireUserId()
      if (!USERNAME_REGEX.matches(normalized)) {
        return Result.failure(
          IllegalArgumentException("Enter 3–24 lowercase letters, numbers, or underscores.")
        )
      }
      val reservationSnap = db.collection("usernames").document(normalized).get().await()
      if (!reservationSnap.exists()) {
        return Result.success(null)
      }
      val targetUid = reservationSnap.getString("uid").orEmpty()
      if (targetUid.isBlank()) {
        return Result.success(null)
      }
      val userSnap = db.collection("users").document(targetUid).get().await()
      val profile =
        if (userSnap.exists()) {
          userSnap.toObject(UserProfile::class.java, ServerTimestampBehavior.ESTIMATE)
        } else {
          null
        }
      Result.success(profile)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.GET, path)
      Result.failure(e)
    }
  }

  suspend fun checkUsernameAvailable(rawUsername: String): Result<Boolean> {
    val normalized = rawUsername.trim().lowercase().removePrefix("@")
    val path = "usernames/$normalized"
    return try {
      val uid = requireUserId()
      if (!USERNAME_REGEX.matches(normalized)) {
        return Result.success(false)
      }
      val snap = db.collection("usernames").document(normalized).get().await()
      val available = !snap.exists() || snap.getString("uid") == uid
      Result.success(available)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.GET, path)
      Result.failure(e)
    }
  }

  suspend fun saveUserProfile(
    username: String,
    displayName: String,
    bio: String,
    photoUrl: String,
  ): Result<UserProfile> {
    val normalizedUsername = username.trim().lowercase().removePrefix("@")
    val cleanDisplayName = displayName.trim().take(50)
    val cleanBio = bio.trim().take(160)
    val cleanPhotoUrl = photoUrl.trim().take(500)
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
    val userPath = "users/$uid"
    return try {
      requireUserId()
      require(USERNAME_REGEX.matches(normalizedUsername)) {
        "Username must be 3–24 lowercase letters, numbers, or underscores."
      }
      require(cleanDisplayName.isNotBlank()) { "Display name cannot be empty." }

      val userRef = db.collection("users").document(uid)
      val newUsernameRef = db.collection("usernames").document(normalizedUsername)

      db.runTransaction { transaction ->
          val existingUserSnap = transaction.get(userRef)
          val newUsernameSnap = transaction.get(newUsernameRef)

          if (newUsernameSnap.exists() && newUsernameSnap.getString("uid") != uid) {
            throw IllegalStateException("Username @$normalizedUsername is already taken.")
          }

          val oldUsername = existingUserSnap.getString("username").orEmpty()
          val oldUsernameRef =
            if (oldUsername.isNotBlank() && oldUsername != normalizedUsername) {
              db.collection("usernames").document(oldUsername)
            } else {
              null
            }
          val oldUsernameSnap = oldUsernameRef?.let { transaction.get(it) }

          if (oldUsernameRef != null && oldUsernameSnap != null && oldUsernameSnap.exists()) {
            if (oldUsernameSnap.getString("uid") == uid) {
              transaction.delete(oldUsernameRef)
            }
          }

          if (!existingUserSnap.exists()) {
            val createUserPayload =
              buildMap<String, Any> {
                put("userId", uid)
                put("username", normalizedUsername)
                put("displayName", cleanDisplayName)
                put("bio", cleanBio)
                if (cleanPhotoUrl.isNotEmpty()) put("photoUrl", cleanPhotoUrl)
                put("createdAt", FieldValue.serverTimestamp())
                put("updatedAt", FieldValue.serverTimestamp())
              }
            transaction.set(userRef, createUserPayload)
          } else {
            val updateUserPayload =
              buildMap<String, Any> {
                put("username", normalizedUsername)
                put("displayName", cleanDisplayName)
                put("bio", cleanBio)
                if (cleanPhotoUrl.isNotEmpty()) put("photoUrl", cleanPhotoUrl)
                put("updatedAt", FieldValue.serverTimestamp())
              }
            transaction.update(userRef, updateUserPayload)
          }

          if (!newUsernameSnap.exists()) {
            val createUsernamePayload =
              buildMap<String, Any> {
                put("uid", uid)
                put("username", normalizedUsername)
                put("displayName", cleanDisplayName)
                if (cleanPhotoUrl.isNotEmpty()) put("photoUrl", cleanPhotoUrl)
                put("createdAt", FieldValue.serverTimestamp())
                put("updatedAt", FieldValue.serverTimestamp())
              }
            transaction.set(newUsernameRef, createUsernamePayload)
          } else {
            val updateUsernamePayload =
              buildMap<String, Any> {
                put("displayName", cleanDisplayName)
                if (cleanPhotoUrl.isNotEmpty()) put("photoUrl", cleanPhotoUrl)
                put("updatedAt", FieldValue.serverTimestamp())
              }
            transaction.update(newUsernameRef, updateUsernamePayload)
          }
        }
        .await()

      val savedSnap = userRef.get().await()
      val savedProfile =
        savedSnap.toObject(UserProfile::class.java, ServerTimestampBehavior.ESTIMATE)
          ?: UserProfile(
            userId = uid,
            username = normalizedUsername,
            displayName = cleanDisplayName,
            bio = cleanBio,
            photoUrl = cleanPhotoUrl,
          )
      Result.success(savedProfile)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, userPath)
      Result.failure(e)
    }
  }

  fun observeContacts(uid: String): Flow<List<ContactEntry>> = flow {
    val currentUid = requireUserId()
    check(currentUid == uid) { "Authenticated user mismatch" }
    val colRef = db.collection("users").document(uid).collection("contacts")
    emitAll(
      colRef
        .snapshots()
        .map { snapshot ->
          snapshot
            .toObjects(ContactEntry::class.java, ServerTimestampBehavior.ESTIMATE)
            .sortedWith(
              compareByDescending<ContactEntry> { it.favorite }
                .thenBy { it.displayName.lowercase() }
            )
        }
        .catch { error ->
          val firestoreError =
            generateSequence(error) { it.cause }
              .filterIsInstance<com.google.firebase.firestore.FirebaseFirestoreException>()
              .firstOrNull()
          if (firestoreError == null && error is CancellationException) throw error
          val ex = firestoreError ?: (error as? Exception)
          if (ex != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(ex, OperationType.LIST, colRef.path)
          }
          throw error
        }
    )
  }

  suspend fun upsertContact(
    contactProfile: UserProfile,
    favorite: Boolean? = null,
    blocked: Boolean? = null,
  ): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
    val path = "users/$uid/contacts/${contactProfile.userId}"
    return try {
      requireUserId()
      require(contactProfile.userId.isNotBlank() && contactProfile.userId != uid) {
        "Invalid contact UID"
      }
      val docRef = db.collection("users").document(uid).collection("contacts").document(contactProfile.userId)
      val existing = docRef.get().await()
      if (!existing.exists()) {
        val payload =
          buildMap<String, Any> {
            put("contactUid", contactProfile.userId)
            put("username", contactProfile.username)
            put("displayName", contactProfile.displayName.take(50))
            if (contactProfile.photoUrl.isNotBlank()) {
              put("photoUrl", contactProfile.photoUrl.take(500))
            }
            put("favorite", favorite ?: false)
            put("blocked", blocked ?: false)
            put("createdAt", FieldValue.serverTimestamp())
            put("updatedAt", FieldValue.serverTimestamp())
          }
        docRef.set(payload).await()
      } else {
        val payload =
          buildMap<String, Any> {
            put("username", contactProfile.username)
            put("displayName", contactProfile.displayName.take(50))
            if (contactProfile.photoUrl.isNotBlank()) {
              put("photoUrl", contactProfile.photoUrl.take(500))
            }
            if (favorite != null) put("favorite", favorite)
            if (blocked != null) put("blocked", blocked)
            put("updatedAt", FieldValue.serverTimestamp())
          }
        docRef.update(payload).await()
      }
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, path)
      Result.failure(e)
    }
  }

  suspend fun setContactFavorite(contactProfile: UserProfile, favorite: Boolean): Result<Unit> =
    upsertContact(contactProfile = contactProfile, favorite = favorite)

  suspend fun setContactBlocked(contactProfile: UserProfile, blocked: Boolean): Result<Unit> =
    upsertContact(contactProfile = contactProfile, blocked = blocked)

  suspend fun removeContact(contactUid: String): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
    val path = "users/$uid/contacts/$contactUid"
    return try {
      requireUserId()
      db.collection("users").document(uid).collection("contacts").document(contactUid).delete().await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, path)
      Result.failure(e)
    }
  }

  suspend fun submitReport(
    reportedUid: String,
    conversationId: String?,
    reason: String,
  ): Result<Unit> {
    val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
    val cleanReason = reason.trim().take(500)
    val docRef = db.collection("reports").document()
    return try {
      requireUserId()
      require(reportedUid.isNotBlank() && reportedUid != uid) { "Invalid reported user." }
      require(cleanReason.length >= 3) { "Please provide at least 3 characters." }
      val payload =
        buildMap<String, Any> {
          put("reporterUid", uid)
          put("reportedUid", reportedUid)
          if (!conversationId.isNullOrBlank()) put("conversationId", conversationId)
          put("reason", cleanReason)
          put("createdAt", FieldValue.serverTimestamp())
        }
      docRef.set(payload).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      Result.failure(e)
    }
  }
}
