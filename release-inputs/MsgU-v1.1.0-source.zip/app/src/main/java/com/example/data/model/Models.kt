package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
  data object Loading : UiState<Nothing>

  data class Success<T>(val data: T) : UiState<T>

  data class Error(val message: String) : UiState<Nothing>
}

enum class MessageType {
  TEXT,
  JELLY_EMOJI,
  CARTOON_EMOJI;

  companion object {
    fun fromRaw(raw: String?): MessageType =
      enumValues<MessageType>().firstOrNull { it.name == raw } ?: TEXT
  }
}

enum class MessageDeliveryStatus {
  SENDING,
  SENT,
  FAILED,
  READ,
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
  @DocumentId val docId: String = "",
  val userId: String = "",
  val username: String = "",
  val displayName: String = "",
  val bio: String = "",
  val photoUrl: String = "",
  @ServerTimestamp val lastActiveAt: Timestamp? = null,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class UsernameReservation(
  @DocumentId val docId: String = "",
  val uid: String = "",
  val username: String = "",
  val displayName: String = "",
  val photoUrl: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class ContactEntry(
  @DocumentId val docId: String = "",
  val contactUid: String = "",
  val username: String = "",
  val displayName: String = "",
  val photoUrl: String = "",
  val favorite: Boolean = false,
  val blocked: Boolean = false,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class Conversation(
  @DocumentId val id: String = "",
  val participantUids: List<String> = emptyList(),
  val participantNames: Map<String, String> = emptyMap(),
  val participantUsernames: Map<String, String> = emptyMap(),
  val participantPhotos: Map<String, String> = emptyMap(),
  val lastMessageText: String = "",
  val lastMessageSenderId: String = "",
  val lastMessageType: String = "NONE",
  @ServerTimestamp val lastMessageAt: Timestamp? = null,
  val unreadCounts: Map<String, Long> = emptyMap(),
  val typingBy: Map<String, Timestamp> = emptyMap(),
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
) {
  fun peerUid(currentUserId: String): String =
    participantUids.firstOrNull { it != currentUserId } ?: ""

  fun peerDisplayName(currentUserId: String): String {
    val peer = peerUid(currentUserId)
    return participantNames[peer]?.takeIf { it.isNotBlank() } ?: "MsgU User"
  }

  fun peerUsername(currentUserId: String): String {
    val peer = peerUid(currentUserId)
    return participantUsernames[peer].orEmpty()
  }

  fun peerPhotoUrl(currentUserId: String): String {
    val peer = peerUid(currentUserId)
    return participantPhotos[peer].orEmpty()
  }

  fun unreadCountFor(userId: String): Long = unreadCounts[userId] ?: 0L

  fun isPeerTyping(currentUserId: String, nowMs: Long = System.currentTimeMillis()): Boolean {
    val peer = peerUid(currentUserId)
    val ts = typingBy[peer]?.toDate()?.time ?: return false
    return (nowMs - ts) in -10_000L..8_000L
  }
}

@Keep
@IgnoreExtraProperties
data class ChatMessage(
  @DocumentId val id: String = "",
  val conversationId: String = "",
  val participantUids: List<String> = emptyList(),
  val senderId: String = "",
  val text: String = "",
  val messageType: String = MessageType.TEXT.name,
  val clientMessageId: String = "",
  val clientTimestampMs: Long = 0L,
  val readBy: List<String> = emptyList(),
  val reactions: Map<String, String> = emptyMap(),
  val replyToMessageId: String? = null,
  val replyToText: String? = null,
  val replyToSenderId: String? = null,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

data class ChatMessageUi(
  val message: ChatMessage,
  val status: MessageDeliveryStatus,
  val isFromCache: Boolean = false,
)

data class ReplyTarget(
  val messageId: String,
  val previewText: String,
  val senderId: String,
  val senderName: String,
)

data class FailedOutboundMessage(
  val clientMessageId: String,
  val text: String,
  val messageType: MessageType,
  val clientTimestampMs: Long,
  val replyTo: ReplyTarget?,
  val errorMessage: String,
)
