package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.firebase.ChatRepository
import com.example.data.firebase.MsgUSettings
import com.example.data.firebase.PreferencesRepository
import com.example.data.firebase.UserRepository
import com.example.data.firebase.authStateFlow
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.notifications.MsgUNotificationHelper
import com.example.notifications.observeNetworkConnectivity
import com.example.ui.components.MsgUAvatar
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.ContactProfileScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileSetupScreen
import com.example.ui.screens.UserSearchScreen
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MsgUTheme
import com.example.ui.theme.PendingAmber
import com.example.ui.viewmodel.ChatViewModel
import com.example.ui.viewmodel.HomeViewModel
import com.example.ui.viewmodel.IncomingNotificationEvent
import com.example.ui.viewmodel.ProfileSetupViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings
import kotlinx.coroutines.delay

data class NotificationDeepLink(val conversationId: String, val peerUid: String)

class MainActivity : ComponentActivity() {
  private val pendingDeepLinkState = mutableStateOf<NotificationDeepLink?>(null)

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    MsgUNotificationHelper.ensureNotificationChannel(this)
    extractDeepLink(intent)
    setContent {
      MsgURootApp(
        pendingDeepLink = pendingDeepLinkState.value,
        onDeepLinkConsumed = { pendingDeepLinkState.value = null },
      )
    }
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
    extractDeepLink(intent)
  }

  private fun extractDeepLink(intent: Intent?) {
    val convId = intent?.getStringExtra(MsgUNotificationHelper.EXTRA_CONVERSATION_ID)
    val peerUid = intent?.getStringExtra(MsgUNotificationHelper.EXTRA_PEER_UID)
    if (!convId.isNullOrBlank() && !peerUid.isNullOrBlank()) {
      pendingDeepLinkState.value = NotificationDeepLink(convId, peerUid)
    }
  }
}

private object Routes {
  const val HOME = "home"
  const val SEARCH = "search"
  const val EDIT_PROFILE = "edit_profile"
  const val CHAT = "chat/{conversationId}/{peerUid}"
  const val CONTACT_PROFILE = "contact_profile/{peerUid}"

  fun chat(conversationId: String, peerUid: String) = "chat/$conversationId/$peerUid"

  fun contactProfile(peerUid: String) = "contact_profile/$peerUid"
}

private fun getConfiguredFirestore(databaseId: String): FirebaseFirestore {
  val db = FirebaseFirestore.getInstance(databaseId)
  try {
    val settings =
      FirebaseFirestoreSettings.Builder()
        .setLocalCacheSettings(
          PersistentCacheSettings.newBuilder()
            .setSizeBytes(100L * 1024L * 1024L)
            .build()
        )
        .build()
    db.firestoreSettings = settings
  } catch (_: IllegalStateException) {
    // Firestore instance already started; persistent cache is already active.
  }
  return db
}

@Composable
fun MsgURootApp(
  auth: FirebaseAuth = Firebase.auth,
  pendingDeepLink: NotificationDeepLink? = null,
  onDeepLinkConsumed: () -> Unit = {},
) {
  val context = LocalContext.current.applicationContext
  val prefsRepo = remember(context) { PreferencesRepository(context) }
  val settings by prefsRepo.settingsFlow.collectAsStateWithLifecycle(initialValue = MsgUSettings())

  val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)

  MsgUTheme(themePreference = settings.themePreference) {
    val user = currentUser
    if (user == null) {
      AuthScreen(onAuthSuccess = {})
    } else {
      key(user.uid) {
        AuthenticatedMsgUApp(
          firebaseUser = user,
          preferencesRepository = prefsRepo,
          pendingDeepLink = pendingDeepLink,
          onDeepLinkConsumed = onDeepLinkConsumed,
        )
      }
    }
  }
}

@Composable
private fun AuthenticatedMsgUApp(
  firebaseUser: FirebaseUser,
  preferencesRepository: PreferencesRepository,
  pendingDeepLink: NotificationDeepLink?,
  onDeepLinkConsumed: () -> Unit,
) {
  val currentUserId = firebaseUser.uid
  val context = LocalContext.current.applicationContext
  val databaseId = remember(context) { context.getString(R.string.firestore_database_id) }
  val db = remember(databaseId) { getConfiguredFirestore(databaseId) }
  val userRepository = remember(db) { UserRepository(db) }
  val chatRepository = remember(db) { ChatRepository(db) }

  val homeViewModel: HomeViewModel =
    viewModel(
      key = "home_$currentUserId",
      factory =
        viewModelFactory {
          initializer {
            val app = checkNotNull(this[APPLICATION_KEY])
            val resolvedDb = getConfiguredFirestore(app.getString(R.string.firestore_database_id))
            HomeViewModel(
              userRepository = UserRepository(resolvedDb),
              chatRepository = ChatRepository(resolvedDb),
              preferencesRepository = PreferencesRepository(app),
              currentUserId = currentUserId,
            )
          }
        },
    )

  val lifecycleOwner = LocalLifecycleOwner.current
  DisposableEffect(lifecycleOwner, homeViewModel) {
    val observer = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_RESUME) {
        homeViewModel.pingPresenceNow()
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  val profileState by homeViewModel.currentUserProfile.collectAsStateWithLifecycle()

  when (val pState = profileState) {
    is UiState.Loading -> {
      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
      }
    }
    is UiState.Error -> {
      val setupVm: ProfileSetupViewModel =
        viewModel(
          key = "setup_err_$currentUserId",
          factory =
            viewModelFactory {
              initializer {
                ProfileSetupViewModel(
                  userRepository = userRepository,
                  currentUserId = currentUserId,
                  initialDisplayName = firebaseUser.displayName.orEmpty(),
                  initialPhotoUrl = firebaseUser.photoUrl?.toString().orEmpty(),
                )
              }
            },
        )
      ProfileSetupScreen(
        viewModel = setupVm,
        isEditingExisting = false,
        onSaved = {},
      )
    }
    is UiState.Success -> {
      val profile = pState.data
      if (profile == null) {
        val setupVm: ProfileSetupViewModel =
          viewModel(
            key = "setup_new_$currentUserId",
            factory =
              viewModelFactory {
                initializer {
                  ProfileSetupViewModel(
                    userRepository = userRepository,
                    currentUserId = currentUserId,
                    initialDisplayName = firebaseUser.displayName.orEmpty(),
                    initialPhotoUrl = firebaseUser.photoUrl?.toString().orEmpty(),
                  )
                }
              },
          )
        ProfileSetupScreen(
          viewModel = setupVm,
          isEditingExisting = false,
          onSaved = {},
        )
      } else {
        MsgUNavHost(
          currentUserId = currentUserId,
          currentProfile = profile,
          homeViewModel = homeViewModel,
          userRepository = userRepository,
          chatRepository = chatRepository,
          preferencesRepository = preferencesRepository,
          pendingDeepLink = pendingDeepLink,
          onDeepLinkConsumed = onDeepLinkConsumed,
        )
      }
    }
  }
}

@Composable
private fun MsgUNavHost(
  currentUserId: String,
  currentProfile: UserProfile,
  homeViewModel: HomeViewModel,
  userRepository: UserRepository,
  chatRepository: ChatRepository,
  preferencesRepository: PreferencesRepository,
  pendingDeepLink: NotificationDeepLink?,
  onDeepLinkConsumed: () -> Unit,
) {
  val context = LocalContext.current.applicationContext
  val haptic = LocalHapticFeedback.current
  val navController = rememberNavController()
  var selectedPeerCache by remember { mutableStateOf<Map<String, UserProfile>>(emptyMap()) }

  val inAppBanner by homeViewModel.inAppBanner.collectAsStateWithLifecycle()
  val isOnline by
    remember(context) { observeNetworkConnectivity(context) }
      .collectAsStateWithLifecycle(initialValue = true)

  LaunchedEffect(homeViewModel) {
    homeViewModel.incomingNotifications.collect { event ->
      MsgUNotificationHelper.showIncomingMessageNotification(
        context = context,
        conversationId = event.conversationId,
        peerUid = event.peerUid,
        senderName = event.senderName,
        messagePreview = event.previewText,
        unreadCount = event.unreadCount,
        showPreview = event.showPreview,
      )
    }
  }

  LaunchedEffect(inAppBanner?.eventId) {
    val banner = inAppBanner ?: return@LaunchedEffect
    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    delay(4_500L)
    if (homeViewModel.inAppBanner.value?.eventId == banner.eventId) {
      homeViewModel.dismissInAppBanner()
    }
  }

  LaunchedEffect(pendingDeepLink) {
    val link = pendingDeepLink ?: return@LaunchedEffect
    navController.navigate(Routes.chat(link.conversationId, link.peerUid)) {
      popUpTo(Routes.HOME)
    }
    onDeepLinkConsumed()
  }

  Box(modifier = Modifier.fillMaxSize()) {
    NavHost(navController = navController, startDestination = Routes.HOME) {
      composable(Routes.HOME) {
        HomeScreen(
          viewModel = homeViewModel,
          onOpenSearch = { navController.navigate(Routes.SEARCH) },
          onOpenChat = { conversationId, peerUid ->
            navController.navigate(Routes.chat(conversationId, peerUid))
          },
          onOpenEditProfile = { navController.navigate(Routes.EDIT_PROFILE) },
          onOpenContactProfile = { peer ->
            selectedPeerCache = selectedPeerCache + (peer.userId to peer)
            navController.navigate(Routes.contactProfile(peer.userId))
          },
          onSignedOut = {},
        )
      }

      composable(Routes.SEARCH) {
        UserSearchScreen(
          viewModel = homeViewModel,
          onBack = { navController.popBackStack() },
          onOpenChat = { conversationId, peerUid ->
            navController.navigate(Routes.chat(conversationId, peerUid)) {
              popUpTo(Routes.HOME)
            }
          },
          onOpenProfile = { peer ->
            selectedPeerCache = selectedPeerCache + (peer.userId to peer)
            navController.navigate(Routes.contactProfile(peer.userId))
          },
        )
      }

      composable(Routes.EDIT_PROFILE) {
        val editVm: ProfileSetupViewModel =
          viewModel(
            key = "edit_${currentUserId}_${currentProfile.username}",
            factory =
              viewModelFactory {
                initializer {
                  ProfileSetupViewModel(
                    userRepository = userRepository,
                    currentUserId = currentUserId,
                    initialDisplayName = currentProfile.displayName,
                    initialPhotoUrl = currentProfile.photoUrl,
                    existingProfile = currentProfile,
                  )
                }
              },
          )
        ProfileSetupScreen(
          viewModel = editVm,
          isEditingExisting = true,
          onBack = { navController.popBackStack() },
          onSaved = { navController.popBackStack() },
        )
      }

      composable(
        route = Routes.CHAT,
        arguments =
          listOf(
            navArgument("conversationId") { type = NavType.StringType },
            navArgument("peerUid") { type = NavType.StringType },
          ),
      ) { backStackEntry ->
        val conversationId = backStackEntry.arguments?.getString("conversationId").orEmpty()
        val peerUid = backStackEntry.arguments?.getString("peerUid").orEmpty()
        DisposableEffect(conversationId) {
          homeViewModel.setActiveConversation(conversationId)
          MsgUNotificationHelper.cancelConversationNotification(context, conversationId)
          onDispose {
            homeViewModel.setActiveConversation(null)
          }
        }
        val chatVm: ChatViewModel =
          viewModel(
            key = "chat_${currentUserId}_$conversationId",
            factory =
              viewModelFactory {
                initializer {
                  ChatViewModel(
                    chatRepository = chatRepository,
                    userRepository = userRepository,
                    preferencesRepository = preferencesRepository,
                    conversationId = conversationId,
                    currentUserId = currentUserId,
                    peerUserId = peerUid,
                    initialCurrentProfile = currentProfile,
                  )
                }
              },
          )
        ChatScreen(
          viewModel = chatVm,
          onBack = { navController.popBackStack() },
          onOpenContactProfile = { peer ->
            selectedPeerCache = selectedPeerCache + (peer.userId to peer)
            navController.navigate(Routes.contactProfile(peer.userId))
          },
        )
      }

      composable(
        route = Routes.CONTACT_PROFILE,
        arguments = listOf(navArgument("peerUid") { type = NavType.StringType }),
      ) { backStackEntry ->
        val peerUid = backStackEntry.arguments?.getString("peerUid").orEmpty()
        val peer =
          selectedPeerCache[peerUid]
            ?: UserProfile(userId = peerUid, username = "msgu_user", displayName = "MsgU User")
        ContactProfileScreen(
          peerUser = peer,
          homeViewModel = homeViewModel,
          userRepository = userRepository,
          onBack = { navController.popBackStack() },
          onOpenChat = { conversationId, uid ->
            navController.navigate(Routes.chat(conversationId, uid)) {
              popUpTo(Routes.HOME)
            }
          },
        )
      }
    }

    // Top overlay stack: Live Offline Pill + Instant In-App Heads-Up Notification Banner
    Column(
      modifier =
        Modifier.align(Alignment.TopCenter)
          .statusBarsPadding()
          .padding(horizontal = 12.dp, vertical = 6.dp)
          .widthIn(max = 560.dp)
          .fillMaxWidth(),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      AnimatedVisibility(
        visible = !isOnline,
        enter = slideInVertically { -it } + fadeIn(),
        exit = slideOutVertically { -it } + fadeOut(),
      ) {
        Surface(
          shape = RoundedCornerShape(20.dp),
          color = PendingAmber,
          shadowElevation = 4.dp,
          modifier = Modifier.padding(bottom = 6.dp),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(
              imageVector = Icons.Default.WifiOff,
              contentDescription = null,
              tint = Color.Black,
              modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Offline • Messages will sync automatically",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.SemiBold,
              color = Color.Black,
            )
          }
        }
      }

      AnimatedVisibility(
        visible = inAppBanner != null,
        enter = slideInVertically { -it } + fadeIn(),
        exit = slideOutVertically { -it } + fadeOut(),
      ) {
        val banner = inAppBanner
        if (banner != null) {
          InAppMessageNotificationBanner(
            event = banner,
            onOpen = {
              homeViewModel.dismissInAppBanner()
              navController.navigate(Routes.chat(banner.conversationId, banner.peerUid)) {
                popUpTo(Routes.HOME)
              }
            },
            onDismiss = { homeViewModel.dismissInAppBanner() },
          )
        }
      }
    }
  }
}

@Composable
private fun InAppMessageNotificationBanner(
  event: IncomingNotificationEvent,
  onOpen: () -> Unit,
  onDismiss: () -> Unit,
) {
  Surface(
    shape = RoundedCornerShape(20.dp),
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = 8.dp,
    shadowElevation = 8.dp,
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(20.dp))
        .clickable(onClick = onOpen)
        .testTag("in_app_notification_banner"),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box {
        MsgUAvatar(
          displayName = event.senderName,
          photoUrl = event.senderPhotoUrl,
          size = 44.dp,
          showRing = true,
        )
        Box(
          modifier =
            Modifier.align(Alignment.TopEnd)
              .size(18.dp)
              .clip(CircleShape)
              .background(ErrorRed),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = event.unreadCount.coerceAtMost(99).toString(),
            style = MaterialTheme.typography.labelSmall,
            color = Color.White,
            fontWeight = FontWeight.Bold,
          )
        }
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = event.senderName,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "now",
            style = MaterialTheme.typography.labelSmall,
            color = ErrorRed,
            fontWeight = FontWeight.SemiBold,
          )
        }
        Text(
          text =
            if (event.showPreview && event.previewText.isNotBlank()) event.previewText
            else "New message • Tap to reply",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
      }
      IconButton(
        onClick = onDismiss,
        modifier = Modifier.size(36.dp),
      ) {
        Icon(
          imageVector = Icons.Default.Close,
          contentDescription = "Dismiss notification",
          tint = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.size(18.dp),
        )
      }
    }
  }
}
