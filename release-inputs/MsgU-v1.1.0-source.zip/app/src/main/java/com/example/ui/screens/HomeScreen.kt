package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Contacts
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ContactEntry
import com.example.data.model.Conversation
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.notifications.MsgUNotificationHelper
import com.example.ui.components.MsgUAvatar
import com.example.ui.theme.ErrorRed
import com.example.ui.viewmodel.HomeViewModel
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
  viewModel: HomeViewModel,
  onOpenSearch: () -> Unit,
  onOpenChat: (conversationId: String, peerUid: String) -> Unit,
  onOpenEditProfile: () -> Unit,
  onOpenContactProfile: (UserProfile) -> Unit,
  onSignedOut: () -> Unit,
) {
  val context = LocalContext.current
  val currentProfileState by viewModel.currentUserProfile.collectAsStateWithLifecycle()
  val conversationsState by viewModel.conversationsState.collectAsStateWithLifecycle()
  val contactsState by viewModel.contactsState.collectAsStateWithLifecycle()
  val settings by viewModel.settingsState.collectAsStateWithLifecycle()
  val chatFilterQuery by viewModel.chatFilterQuery.collectAsStateWithLifecycle()
  val actionMessage by viewModel.actionMessage.collectAsStateWithLifecycle()

  val lifecycleOwner = LocalLifecycleOwner.current
  var hasNotificationPermission by remember {
    mutableStateOf(MsgUNotificationHelper.hasNotificationPermission(context))
  }
  DisposableEffect(lifecycleOwner, context) {
    val observer = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_RESUME) {
        hasNotificationPermission = MsgUNotificationHelper.hasNotificationPermission(context)
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  var askedNotificationOnce by rememberSaveable { mutableStateOf(false) }

  val notificationPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      hasNotificationPermission = MsgUNotificationHelper.hasNotificationPermission(context)
      if (granted) {
        viewModel.setNotificationsEnabled(true)
      }
    }

  val requestOrOpenNotificationSettings: () -> Unit = {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !askedNotificationOnce) {
      askedNotificationOnce = true
      notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    } else {
      MsgUNotificationHelper.openAppNotificationSettings(context)
    }
  }

  LaunchedEffect(Unit) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission && !askedNotificationOnce) {
      askedNotificationOnce = true
      notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
  }

  var selectedTab by rememberSaveable { mutableIntStateOf(0) }
  var showChatFilterBar by rememberSaveable { mutableStateOf(false) }
  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(actionMessage) {
    val msg = actionMessage
    if (!msg.isNullOrBlank()) {
      snackbarHostState.showSnackbar(msg)
      viewModel.clearActionMessage()
    }
  }

  val conversations = (conversationsState as? UiState.Success)?.data.orEmpty()
  val totalUnreadCount =
    conversations.sumOf { it.unreadCountFor(viewModel.currentUserId).toInt() }
  val currentProfile = (currentProfileState as? UiState.Success)?.data

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val useRail = maxWidth >= 600.dp

    Row(modifier = Modifier.fillMaxSize()) {
      if (useRail) {
        NavigationRail(modifier = Modifier.fillMaxHeight()) {
          Spacer(modifier = Modifier.height(12.dp))
          NavigationRailItem(
            selected = selectedTab == 0,
            onClick = { selectedTab = 0 },
            icon = {
              BadgedBox(
                badge = {
                  if (totalUnreadCount > 0) {
                    Badge(containerColor = ErrorRed, contentColor = Color.White) {
                      Text(totalUnreadCount.toString())
                    }
                  }
                }
              ) {
                Icon(
                  if (selectedTab == 0) Icons.AutoMirrored.Filled.Chat
                  else Icons.AutoMirrored.Outlined.Chat,
                  contentDescription = "Chats",
                )
              }
            },
            label = { Text("Chats") },
            modifier = Modifier.testTag("nav_chats"),
          )
          NavigationRailItem(
            selected = selectedTab == 1,
            onClick = { selectedTab = 1 },
            icon = {
              Icon(
                if (selectedTab == 1) Icons.Filled.Contacts else Icons.Outlined.Contacts,
                contentDescription = "Contacts",
              )
            },
            label = { Text("Contacts") },
            modifier = Modifier.testTag("nav_contacts"),
          )
          NavigationRailItem(
            selected = selectedTab == 2,
            onClick = { selectedTab = 2 },
            icon = {
              BadgedBox(
                badge = {
                  if (!hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    Badge(containerColor = ErrorRed)
                  }
                }
              ) {
                Icon(
                  if (selectedTab == 2) Icons.Filled.Settings else Icons.Outlined.Settings,
                  contentDescription = "Settings",
                )
              }
            },
            label = { Text("Settings") },
            modifier = Modifier.testTag("nav_settings"),
          )
        }
      }

      Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        contentWindowInsets = WindowInsets.navigationBars,
        topBar = {
          TopAppBar(
            title = {
              Column {
                Text(
                  text =
                    when (selectedTab) {
                      0 -> "MsgU"
                      1 -> "Contacts"
                      else -> "Settings"
                    },
                  style = MaterialTheme.typography.titleLarge,
                )
                if (selectedTab == 0 && currentProfile != null) {
                  Text(
                    text = "@${currentProfile.username}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                  )
                }
              }
            },
            actions = {
              if (selectedTab == 0) {
                IconButton(
                  onClick = { showChatFilterBar = !showChatFilterBar },
                  modifier = Modifier.testTag("home_filter_button"),
                ) {
                  Icon(Icons.Default.Search, contentDescription = "Filter chats")
                }
                IconButton(
                  onClick = onOpenSearch,
                  modifier = Modifier.testTag("home_new_chat_button"),
                ) {
                  Icon(Icons.Default.AddComment, contentDescription = "New Chat")
                }
              }
              if (currentProfile != null) {
                IconButton(
                  onClick = onOpenEditProfile,
                  modifier = Modifier.testTag("home_profile_button"),
                ) {
                  MsgUAvatar(
                    displayName = currentProfile.displayName,
                    photoUrl = currentProfile.photoUrl,
                    size = 32.dp,
                  )
                }
              }
              IconButton(
                onClick = { selectedTab = 2 },
                modifier = Modifier.testTag("home_settings_button"),
              ) {
                BadgedBox(
                  badge = {
                    if (!hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                      Badge(containerColor = ErrorRed)
                    }
                  }
                ) {
                  Icon(Icons.Outlined.Settings, contentDescription = "Settings")
                }
              }
            },
          )
        },
        floatingActionButton = {
          if (selectedTab != 2) {
            FloatingActionButton(
              onClick = onOpenSearch,
              containerColor = MaterialTheme.colorScheme.primary,
              contentColor = MaterialTheme.colorScheme.onPrimary,
              modifier = Modifier.testTag("fab_new_chat"),
            ) {
              Icon(Icons.Default.AddComment, contentDescription = "Find User & Start Chat")
            }
          }
        },
        bottomBar = {
          if (!useRail) {
            NavigationBar {
              NavigationBarItem(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                icon = {
                  BadgedBox(
                    badge = {
                      if (totalUnreadCount > 0) {
                        Badge(containerColor = ErrorRed, contentColor = Color.White) {
                          Text(totalUnreadCount.toString())
                        }
                      }
                    }
                  ) {
                    Icon(
                      if (selectedTab == 0) Icons.AutoMirrored.Filled.Chat
                      else Icons.AutoMirrored.Outlined.Chat,
                      contentDescription = "Chats",
                    )
                  }
                },
                label = { Text("Chats") },
                modifier = Modifier.testTag("nav_chats"),
              )
              NavigationBarItem(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                icon = {
                  Icon(
                    if (selectedTab == 1) Icons.Filled.Contacts else Icons.Outlined.Contacts,
                    contentDescription = "Contacts",
                  )
                },
                label = { Text("Contacts") },
                modifier = Modifier.testTag("nav_contacts"),
              )
              NavigationBarItem(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                icon = {
                  BadgedBox(
                    badge = {
                      if (!hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        Badge(containerColor = ErrorRed)
                      }
                    }
                  ) {
                    Icon(
                      if (selectedTab == 2) Icons.Filled.Settings else Icons.Outlined.Settings,
                      contentDescription = "Settings",
                    )
                  }
                },
                label = { Text("Settings") },
                modifier = Modifier.testTag("nav_settings"),
              )
            }
          }
        },
      ) { innerPadding ->
        Box(
          modifier = Modifier.fillMaxSize().padding(innerPadding),
          contentAlignment = Alignment.TopCenter,
        ) {
          Column(modifier = Modifier.widthIn(max = 720.dp).fillMaxSize()) {
            if (selectedTab == 0 && !hasNotificationPermission) {
              Surface(
                color = ErrorRed.copy(alpha = 0.10f),
                shape = RoundedCornerShape(16.dp),
                modifier =
                  Modifier.fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Icon(
                    imageVector = Icons.Default.NotificationsActive,
                    contentDescription = null,
                    tint = ErrorRed,
                    modifier = Modifier.size(20.dp),
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Text(
                    text = "Notifications are off. Turn on alerts for new messages.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f),
                  )
                  TextButton(onClick = requestOrOpenNotificationSettings) {
                    Text("Turn On", color = ErrorRed, fontWeight = FontWeight.Bold)
                  }
                }
              }
            }

            when (selectedTab) {
              0 ->
                ChatsTabContent(
                  currentUserId = viewModel.currentUserId,
                  conversationsState = conversationsState,
                  filterQuery = chatFilterQuery,
                  showFilterBar = showChatFilterBar,
                  showMessagePreviews = settings.showMessagePreviews,
                  onFilterQueryChange = viewModel::updateChatFilterQuery,
                  onStartNewChat = onOpenSearch,
                  onOpenChat = onOpenChat,
                )
              1 ->
                ContactsTabContent(
                  contactsState = contactsState,
                  onFindUsers = onOpenSearch,
                  onToggleFavorite = viewModel::toggleFavoriteContact,
                  onOpenChat = { contact ->
                    val peer =
                      UserProfile(
                        userId = contact.contactUid,
                        username = contact.username,
                        displayName = contact.displayName,
                        photoUrl = contact.photoUrl,
                      )
                    viewModel.startConversationWithUser(peer, onOpenChat)
                  },
                  onOpenProfile = { contact ->
                    onOpenContactProfile(
                      UserProfile(
                        userId = contact.contactUid,
                        username = contact.username,
                        displayName = contact.displayName,
                        photoUrl = contact.photoUrl,
                      )
                    )
                  },
                )
              else ->
                SettingsScreen(
                  currentProfile = currentProfile,
                  settings = settings,
                  hasNotificationPermission = hasNotificationPermission,
                  onRequestNotificationPermission = requestOrOpenNotificationSettings,
                  onOpenSystemNotificationSettings = {
                    MsgUNotificationHelper.openAppNotificationSettings(context)
                  },
                  onSendTestNotification = {
                    val sent = MsgUNotificationHelper.showTestNotification(context)
                    if (!sent) {
                      MsgUNotificationHelper.openAppNotificationSettings(context)
                    }
                  },
                  onEditProfile = onOpenEditProfile,
                  onThemeSelected = viewModel::setThemePreference,
                  onToggleNotifications = viewModel::setNotificationsEnabled,
                  onToggleMessagePreviews = viewModel::setShowMessagePreviews,
                  onToggleReadReceipts = viewModel::setSendReadReceipts,
                  onSignedOut = onSignedOut,
                )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun ChatsTabContent(
  currentUserId: String,
  conversationsState: UiState<List<Conversation>>,
  filterQuery: String,
  showFilterBar: Boolean,
  showMessagePreviews: Boolean,
  onFilterQueryChange: (String) -> Unit,
  onStartNewChat: () -> Unit,
  onOpenChat: (conversationId: String, peerUid: String) -> Unit,
) {
  Column(modifier = Modifier.fillMaxSize()) {
    if (showFilterBar) {
      OutlinedTextField(
        value = filterQuery,
        onValueChange = onFilterQueryChange,
        placeholder = { Text("Filter conversations…") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        modifier =
          Modifier.fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("chat_filter_input"),
      )
    }

    when (conversationsState) {
      is UiState.Loading -> {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          CircularProgressIndicator()
        }
      }
      is UiState.Error -> {
        EmptyStateCard(
          title = "Unable to load chats",
          subtitle = conversationsState.message,
          buttonLabel = "Search Users",
          onAction = onStartNewChat,
        )
      }
      is UiState.Success -> {
        val filtered =
          conversationsState.data.filter { conv ->
            if (filterQuery.isBlank()) true
            else {
              val q = filterQuery.trim().lowercase()
              conv.peerDisplayName(currentUserId).lowercase().contains(q) ||
                conv.peerUsername(currentUserId).lowercase().contains(q) ||
                conv.lastMessageText.lowercase().contains(q)
            }
          }

        if (filtered.isEmpty()) {
          EmptyStateCard(
            title = if (filterQuery.isBlank()) "No conversations yet" else "No matching chats",
            subtitle =
              if (filterQuery.isBlank()) {
                "Tap + to search a friend's exact @username and start a real-time chat."
              } else {
                "Try a different search filter or start a new conversation."
              },
            buttonLabel = "Find Friends by @username",
            onAction = onStartNewChat,
          )
        } else {
          LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(vertical = 8.dp),
          ) {
            items(filtered, key = { it.id }) { conv ->
              ConversationListItem(
                conversation = conv,
                currentUserId = currentUserId,
                showMessagePreviews = showMessagePreviews,
                onClick = { onOpenChat(conv.id, conv.peerUid(currentUserId)) },
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun ConversationListItem(
  conversation: Conversation,
  currentUserId: String,
  showMessagePreviews: Boolean,
  onClick: () -> Unit,
) {
  val peerName = conversation.peerDisplayName(currentUserId)
  val peerUsername = conversation.peerUsername(currentUserId)
  val peerPhoto = conversation.peerPhotoUrl(currentUserId)
  val unread = conversation.unreadCountFor(currentUserId)
  val peerTyping = conversation.isPeerTyping(currentUserId)
  val timeText =
    remember(conversation.lastMessageAt, conversation.updatedAt) {
      val date = (conversation.lastMessageAt ?: conversation.updatedAt)?.toDate()
      if (date != null) SimpleDateFormat("h:mm a", Locale.getDefault()).format(date) else ""
    }

  val previewText =
    when {
      peerTyping -> "typing…"
      !showMessagePreviews && unread > 0L -> "New message"
      conversation.lastMessageText.isBlank() -> "Tap to send a message"
      conversation.lastMessageSenderId == currentUserId -> "You: ${conversation.lastMessageText}"
      else -> conversation.lastMessageText
    }

  Row(
    modifier =
      Modifier.fillMaxWidth()
        .clickable(onClick = onClick)
        .padding(horizontal = 16.dp, vertical = 12.dp)
        .testTag("conversation_item_${conversation.id}"),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    MsgUAvatar(
      displayName = peerName,
      photoUrl = peerPhoto,
      size = 54.dp,
      showRing = unread > 0L || peerTyping,
    )
    Spacer(modifier = Modifier.width(14.dp))
    Column(modifier = Modifier.weight(1f)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = peerName,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = if (unread > 0L) FontWeight.Bold else FontWeight.SemiBold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f),
        )
        if (timeText.isNotBlank()) {
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = timeText,
            style = MaterialTheme.typography.labelSmall,
            color =
              if (unread > 0L) ErrorRed
              else MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
      Spacer(modifier = Modifier.height(3.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text =
            if (!peerTyping && peerUsername.isNotBlank() && conversation.lastMessageText.isBlank()) {
              "@$peerUsername • Tap to chat"
            } else {
              previewText
            },
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = if (peerTyping) FontWeight.SemiBold else FontWeight.Normal,
          color =
            when {
              peerTyping -> MaterialTheme.colorScheme.primary
              unread > 0L -> MaterialTheme.colorScheme.onSurface
              else -> MaterialTheme.colorScheme.onSurfaceVariant
            },
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f),
        )
        if (unread > 0L) {
          Spacer(modifier = Modifier.width(8.dp))
          Box(
            modifier =
              Modifier.clip(CircleShape)
                .background(ErrorRed)
                .padding(horizontal = 8.dp, vertical = 3.dp)
                .testTag("unread_badge_${conversation.id}"),
            contentAlignment = Alignment.Center,
          ) {
            Text(
              text = unread.toString(),
              style = MaterialTheme.typography.labelSmall,
              color = Color.White,
              fontWeight = FontWeight.Bold,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun ContactsTabContent(
  contactsState: UiState<List<ContactEntry>>,
  onFindUsers: () -> Unit,
  onToggleFavorite: (ContactEntry) -> Unit,
  onOpenChat: (ContactEntry) -> Unit,
  onOpenProfile: (ContactEntry) -> Unit,
) {
  when (contactsState) {
    is UiState.Loading -> {
      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
      }
    }
    is UiState.Error -> {
      EmptyStateCard(
        title = "Unable to load contacts",
        subtitle = contactsState.message,
        buttonLabel = "Search Users",
        onAction = onFindUsers,
      )
    }
    is UiState.Success -> {
      if (contactsState.data.isEmpty()) {
        EmptyStateCard(
          title = "No saved contacts yet",
          subtitle = "Search any MsgU user by their exact @username to add them and start messaging.",
          buttonLabel = "Search MsgU Users",
          onAction = onFindUsers,
        )
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(vertical = 8.dp),
        ) {
          items(contactsState.data, key = { it.contactUid }) { contact ->
            Row(
              modifier =
                Modifier.fillMaxWidth()
                  .clickable { onOpenProfile(contact) }
                  .padding(horizontal = 16.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              MsgUAvatar(
                displayName = contact.displayName,
                photoUrl = contact.photoUrl,
                size = 50.dp,
              )
              Spacer(modifier = Modifier.width(14.dp))
              Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = contact.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                  if (contact.blocked) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                      Icons.Default.Block,
                      contentDescription = "Blocked",
                      tint = MaterialTheme.colorScheme.error,
                      modifier = Modifier.size(15.dp),
                    )
                  }
                }
                Text(
                  text = "@${contact.username}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.primary,
                )
              }
              IconButton(onClick = { onToggleFavorite(contact) }) {
                Icon(
                  imageVector =
                    if (contact.favorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                  contentDescription = if (contact.favorite) "Remove favorite" else "Add favorite",
                  tint =
                    if (contact.favorite) MaterialTheme.colorScheme.secondary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
              IconButton(onClick = { onOpenChat(contact) }) {
                Icon(
                  imageVector = Icons.AutoMirrored.Filled.Chat,
                  contentDescription = "Chat with ${contact.displayName}",
                  tint = MaterialTheme.colorScheme.primary,
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun EmptyStateCard(
  title: String,
  subtitle: String,
  buttonLabel: String,
  onAction: () -> Unit,
) {
  Box(
    modifier = Modifier.fillMaxSize().padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Surface(
      shape = RoundedCornerShape(24.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 2.dp,
      modifier = Modifier.fillMaxWidth().widthIn(max = 420.dp),
    ) {
      Column(
        modifier = Modifier.padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        Surface(
          shape = CircleShape,
          color = MaterialTheme.colorScheme.primaryContainer,
          modifier = Modifier.size(64.dp),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.Chat,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(30.dp),
            )
          }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
          text = title,
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(20.dp))
        Button(
          onClick = onAction,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("empty_state_action"),
        ) {
          Text(buttonLabel)
        }
      }
    }
  }
}
