package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.components.MsgUAvatar
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.ProfileSetupViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileSetupScreen(
  viewModel: ProfileSetupViewModel,
  isEditingExisting: Boolean,
  onBack: (() -> Unit)? = null,
  onSaved: () -> Unit,
) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()

  LaunchedEffect(state.savedSuccess) {
    if (state.savedSuccess) {
      onSaved()
    }
  }

  Scaffold(
    topBar = {
      if (isEditingExisting && onBack != null) {
        TopAppBar(
          title = { Text("Edit Profile") },
          navigationIcon = {
            IconButton(onClick = onBack, modifier = Modifier.testTag("profile_back_button")) {
              Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
          },
        )
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier.fillMaxSize().padding(innerPadding).imePadding(),
      contentAlignment = Alignment.TopCenter,
    ) {
      Column(
        modifier =
          Modifier.widthIn(max = 540.dp)
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        MsgUAvatar(
          displayName = state.displayNameInput.ifBlank { "MsgU" },
          photoUrl = state.photoUrl,
          size = 88.dp,
          showRing = true,
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
          text =
            if (isEditingExisting) "Update Your MsgU Profile"
            else stringResource(id = R.string.profile_setup_title),
          style = MaterialTheme.typography.headlineSmall,
          color = MaterialTheme.colorScheme.onBackground,
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = stringResource(id = R.string.profile_setup_subtitle),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
          value = state.usernameInput,
          onValueChange = viewModel::onUsernameChanged,
          label = { Text("Unique Username") },
          leadingIcon = {
            Icon(Icons.Default.AlternateEmail, contentDescription = null)
          },
          trailingIcon = {
            when {
              state.isCheckingUsername ->
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
              state.usernameValidationError != null ->
                Icon(
                  Icons.Default.ErrorOutline,
                  contentDescription = "Unavailable",
                  tint = MaterialTheme.colorScheme.error,
                )
              state.isUsernameAvailable == true ->
                Icon(
                  Icons.Default.CheckCircle,
                  contentDescription = "Available",
                  tint = SuccessGreen,
                )
            }
          },
          supportingText = {
            val helper =
              when {
                state.usernameValidationError != null -> state.usernameValidationError!!
                state.isUsernameAvailable == true -> "@${state.usernameInput} is available"
                else -> "3–24 lowercase letters, numbers, or underscores"
              }
            Text(
              text = helper,
              color =
                when {
                  state.usernameValidationError != null -> MaterialTheme.colorScheme.error
                  state.isUsernameAvailable == true -> SuccessGreen
                  else -> MaterialTheme.colorScheme.onSurfaceVariant
                },
            )
          },
          isError = state.usernameValidationError != null,
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().testTag("username_input"),
        )

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
          value = state.displayNameInput,
          onValueChange = viewModel::onDisplayNameChanged,
          label = { Text("Display Name") },
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().testTag("display_name_input"),
        )

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
          value = state.bioInput,
          onValueChange = viewModel::onBioChanged,
          label = { Text("Bio (Optional)") },
          placeholder = { Text("Hey there! Let's chat on MsgU.") },
          maxLines = 3,
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth().testTag("bio_input"),
        )

        if (!state.errorMessage.isNullOrBlank()) {
          Spacer(modifier = Modifier.height(14.dp))
          Surface(
            color = MaterialTheme.colorScheme.error.copy(alpha = 0.12f),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text(
              text = state.errorMessage!!,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.error,
              modifier = Modifier.padding(14.dp),
            )
          }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
          onClick = viewModel::saveProfile,
          enabled =
            !state.isSaving &&
              state.usernameValidationError == null &&
              state.displayNameInput.isNotBlank(),
          shape = RoundedCornerShape(16.dp),
          modifier =
            Modifier.fillMaxWidth()
              .height(54.dp)
              .testTag("save_profile_button"),
        ) {
          if (state.isSaving) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center,
            ) {
              CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                color = MaterialTheme.colorScheme.onPrimary,
                strokeWidth = 2.dp,
              )
              Spacer(modifier = Modifier.width(10.dp))
              Text("Reserving @${state.usernameInput}…")
            }
          } else {
            Text(if (isEditingExisting) "Save Changes" else "Continue to MsgU")
          }
        }
      }
    }
  }
}
