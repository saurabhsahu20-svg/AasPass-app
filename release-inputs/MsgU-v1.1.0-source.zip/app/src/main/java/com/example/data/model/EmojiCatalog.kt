package com.example.data.model

import androidx.annotation.DrawableRes
import androidx.compose.ui.graphics.Color
import com.example.R

enum class EmojiPack(val title: String) {
  CRYSTAL_JELLY("Crystal Jelly 3D"),
  FUNNY_ANIMATED("Animated 3D"),
  CUTE_CARTOON("Cute 3D Cartoon"),
}

data class MsgUCustomEmoji(
  val token: String,
  val label: String,
  val pack: EmojiPack,
  val primaryColor: Color,
  val secondaryColor: Color,
  val glyph: String,
  @DrawableRes val drawableRes: Int? = null,
  val animationKind: String = "none",
  val keywords: List<String> = emptyList(),
)

data class StandardEmojiCategory(
  val id: String,
  val icon: String,
  val title: String,
  val emojis: List<Pair<String, String>>, // glyph to searchable label
)

object EmojiCatalog {

  val quickReactions: List<String> = listOf("❤️", "😂", "😍", "🙏", "👍", "🫶")

  // PHASE 1: First 20 Exclusive MsgU Crystal Jelly 3D Emojis (real transparent 3D WebP assets)
  val crystalJelly20: List<MsgUCustomEmoji> =
    listOf(
      MsgUCustomEmoji(
        token = "[jelly:love_eyes]",
        label = "Cute Love Eyes",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFFFF7EB6),
        secondaryColor = Color(0xFF60A5FA),
        glyph = "😍",
        drawableRes = R.drawable.img_jelly_01_love_eyes,
        keywords = listOf("love", "heart", "eyes", "crush", "adore", "cute"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:funny_laugh]",
        label = "Super Funny Laugh",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFFFDE047),
        secondaryColor = Color(0xFF22D3EE),
        glyph = "😂",
        drawableRes = R.drawable.img_jelly_02_funny_laugh,
        keywords = listOf("laugh", "funny", "lol", "haha", "tears", "joy"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:sweet_happy]",
        label = "Sweet Happy Face",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFFFDBA74),
        secondaryColor = Color(0xFFF472B6),
        glyph = "🥰",
        drawableRes = R.drawable.img_jelly_03_sweet_happy,
        keywords = listOf("sweet", "happy", "smile", "hearts", "warm", "blush"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:cool_cartoon]",
        label = "Cool Cartoon",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFF22D3EE),
        secondaryColor = Color(0xFF2563EB),
        glyph = "😎",
        drawableRes = R.drawable.img_jelly_04_cool_cartoon,
        keywords = listOf("cool", "sunglasses", "swag", "chill", "awesome"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:sending_hearts]",
        label = "Sending Hearts",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFFC084FC),
        secondaryColor = Color(0xFFF472B6),
        glyph = "😘",
        drawableRes = R.drawable.img_jelly_05_sending_hearts,
        keywords = listOf("kiss", "heart", "love", "wink", "sending"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:cute_crying]",
        label = "Cute Crying",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFF93C5FD),
        secondaryColor = Color(0xFF38BDF8),
        glyph = "😭",
        drawableRes = R.drawable.img_jelly_06_cute_crying,
        keywords = listOf("cry", "sad", "tears", "emotional", "sorry"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:funny_angry]",
        label = "Funny Angry",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFFFB7185),
        secondaryColor = Color(0xFFEF4444),
        glyph = "😡",
        drawableRes = R.drawable.img_jelly_07_funny_angry,
        keywords = listOf("angry", "mad", "annoyed", "grumpy", "puff"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:thinking]",
        label = "Thinking Cartoon",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFFA78BFA),
        secondaryColor = Color(0xFF6366F1),
        glyph = "🤔",
        drawableRes = R.drawable.img_jelly_08_thinking,
        keywords = listOf("think", "hmm", "wonder", "question", "idea"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:sleepy]",
        label = "Adorable Sleepy",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFFD8B4FE),
        secondaryColor = Color(0xFF67E8F9),
        glyph = "😴",
        drawableRes = R.drawable.img_jelly_09_sleepy,
        keywords = listOf("sleep", "tired", "goodnight", "zzz", "relax"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:surprised]",
        label = "Super Surprised",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFF67E8F9),
        secondaryColor = Color(0xFFFDE047),
        glyph = "😲",
        drawableRes = R.drawable.img_jelly_10_surprised,
        keywords = listOf("wow", "shocked", "surprised", "omg", "amazed"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:sparkling_eyes]",
        label = "Sparkling Eyes",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFFFACC15),
        secondaryColor = Color(0xFF22D3EE),
        glyph = "🤩",
        drawableRes = R.drawable.img_jelly_11_sparkling_eyes,
        keywords = listOf("star", "sparkle", "excited", "amazing", "wow"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:funny_tongue]",
        label = "Funny Tongue",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFFF472B6),
        secondaryColor = Color(0xFF06B6D4),
        glyph = "😜",
        drawableRes = R.drawable.img_jelly_12_funny_tongue,
        keywords = listOf("silly", "tongue", "wink", "playful", "crazy"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:innocent_smile]",
        label = "Innocent Smile",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFFFED7AA),
        secondaryColor = Color(0xFF93C5FD),
        glyph = "😇",
        drawableRes = R.drawable.img_jelly_13_innocent_smile,
        keywords = listOf("angel", "innocent", "halo", "sweet", "bless"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:shy_expression]",
        label = "Shy Expression",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFFF9A8D4),
        secondaryColor = Color(0xFFC084FC),
        glyph = "🫣",
        drawableRes = R.drawable.img_jelly_14_shy_expression,
        keywords = listOf("shy", "peek", "blush", "cute", "embarrassed"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:birthday]",
        label = "Birthday Celebration",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFF2DD4BF),
        secondaryColor = Color(0xFFF472B6),
        glyph = "🥳",
        drawableRes = R.drawable.img_jelly_15_birthday,
        keywords = listOf("birthday", "party", "celebrate", "congrats", "festival"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:cute_namaste]",
        label = "Cute Namaste",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFFFDBA74),
        secondaryColor = Color(0xFFF59E0B),
        glyph = "🙏",
        drawableRes = R.drawable.img_jelly_16_cute_namaste,
        keywords = listOf("namaste", "thanks", "please", "india", "greet", "pray"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:happy_hello]",
        label = "Happy Hello",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFF38BDF8),
        secondaryColor = Color(0xFF34D399),
        glyph = "👋",
        drawableRes = R.drawable.img_jelly_17_happy_hello,
        keywords = listOf("hello", "hi", "hey", "wave", "bye", "welcome"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:crystal_heart]",
        label = "Crystal Heart",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFFF43F5E),
        secondaryColor = Color(0xFFEC4899),
        glyph = "❤️",
        drawableRes = R.drawable.img_jelly_18_crystal_heart,
        keywords = listOf("heart", "love", "crystal", "romance", "care"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:thumbs_up]",
        label = "Cute Thumbs Up",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFF4ADE80),
        secondaryColor = Color(0xFF06B6D4),
        glyph = "👍",
        drawableRes = R.drawable.img_jelly_19_thumbs_up,
        keywords = listOf("thumbs", "ok", "yes", "nice", "good", "agree"),
      ),
      MsgUCustomEmoji(
        token = "[jelly:friendship]",
        label = "Friendship Reaction",
        pack = EmojiPack.CRYSTAL_JELLY,
        primaryColor = Color(0xFFC084FC),
        secondaryColor = Color(0xFFF472B6),
        glyph = "🫶",
        drawableRes = R.drawable.img_jelly_20_friendship,
        keywords = listOf("friend", "friendship", "heart hands", "bestie", "care"),
      ),
    )

  // Collection 3: 10 Smooth Animated 3D Reactions (built on real 3D Crystal Jelly assets, reduced-motion aware)
  val funnyAnimated: List<MsgUCustomEmoji> =
    listOf(
      MsgUCustomEmoji(
        token = "[anim:laughing_jelly]",
        label = "Laughing",
        pack = EmojiPack.FUNNY_ANIMATED,
        primaryColor = Color(0xFFFDE047),
        secondaryColor = Color(0xFF22D3EE),
        glyph = "😂",
        drawableRes = R.drawable.img_jelly_02_funny_laugh,
        animationKind = "bounce",
        keywords = listOf("laughing", "funny", "rofl", "animated"),
      ),
      MsgUCustomEmoji(
        token = "[anim:celebrating_jelly]",
        label = "Celebrating",
        pack = EmojiPack.FUNNY_ANIMATED,
        primaryColor = Color(0xFF2DD4BF),
        secondaryColor = Color(0xFFF472B6),
        glyph = "🥳",
        drawableRes = R.drawable.img_jelly_15_birthday,
        animationKind = "jump",
        keywords = listOf("celebrating", "party", "birthday", "animated"),
      ),
      MsgUCustomEmoji(
        token = "[anim:dancing_jelly]",
        label = "Dancing",
        pack = EmojiPack.FUNNY_ANIMATED,
        primaryColor = Color(0xFFFACC15),
        secondaryColor = Color(0xFF22D3EE),
        glyph = "🤩",
        drawableRes = R.drawable.img_jelly_11_sparkling_eyes,
        animationKind = "dance",
        keywords = listOf("dancing", "vibe", "excited", "animated"),
      ),
      MsgUCustomEmoji(
        token = "[anim:winking_jelly]",
        label = "Winking",
        pack = EmojiPack.FUNNY_ANIMATED,
        primaryColor = Color(0xFFF472B6),
        secondaryColor = Color(0xFF06B6D4),
        glyph = "😜",
        drawableRes = R.drawable.img_jelly_12_funny_tongue,
        animationKind = "wiggle",
        keywords = listOf("winking", "playful", "tongue", "animated"),
      ),
      MsgUCustomEmoji(
        token = "[anim:waving_jelly]",
        label = "Waving",
        pack = EmojiPack.FUNNY_ANIMATED,
        primaryColor = Color(0xFF38BDF8),
        secondaryColor = Color(0xFF34D399),
        glyph = "👋",
        drawableRes = R.drawable.img_jelly_17_happy_hello,
        animationKind = "wiggle",
        keywords = listOf("waving", "hello", "hi", "animated"),
      ),
      MsgUCustomEmoji(
        token = "[anim:clapping_jelly]",
        label = "Cheering",
        pack = EmojiPack.FUNNY_ANIMATED,
        primaryColor = Color(0xFF4ADE80),
        secondaryColor = Color(0xFF06B6D4),
        glyph = "👍",
        drawableRes = R.drawable.img_jelly_19_thumbs_up,
        animationKind = "bounce",
        keywords = listOf("clapping", "thumbs", "nice", "animated"),
      ),
      MsgUCustomEmoji(
        token = "[anim:jumping_jelly]",
        label = "Jumping",
        pack = EmojiPack.FUNNY_ANIMATED,
        primaryColor = Color(0xFFFDBA74),
        secondaryColor = Color(0xFFF472B6),
        glyph = "🥰",
        drawableRes = R.drawable.img_jelly_03_sweet_happy,
        animationKind = "jump",
        keywords = listOf("jumping", "happy", "joy", "animated"),
      ),
      MsgUCustomEmoji(
        token = "[anim:blushing_jelly]",
        label = "Blushing",
        pack = EmojiPack.FUNNY_ANIMATED,
        primaryColor = Color(0xFFF9A8D4),
        secondaryColor = Color(0xFFC084FC),
        glyph = "🫣",
        drawableRes = R.drawable.img_jelly_14_shy_expression,
        animationKind = "pulse",
        keywords = listOf("blushing", "shy", "cute", "animated"),
      ),
      MsgUCustomEmoji(
        token = "[anim:sending_hearts_jelly]",
        label = "Sending Hearts",
        pack = EmojiPack.FUNNY_ANIMATED,
        primaryColor = Color(0xFFC084FC),
        secondaryColor = Color(0xFFF472B6),
        glyph = "😘",
        drawableRes = R.drawable.img_jelly_05_sending_hearts,
        animationKind = "heartbeat",
        keywords = listOf("hearts", "love", "kiss", "animated"),
      ),
      MsgUCustomEmoji(
        token = "[anim:sleeping_jelly]",
        label = "Sleeping",
        pack = EmojiPack.FUNNY_ANIMATED,
        primaryColor = Color(0xFFD8B4FE),
        secondaryColor = Color(0xFF67E8F9),
        glyph = "😴",
        drawableRes = R.drawable.img_jelly_09_sleepy,
        animationKind = "float",
        keywords = listOf("sleeping", "goodnight", "dream", "animated"),
      ),
    )

  // Complete Categorized Standard Emoji Library (all requested categories)
  val standardCategories: List<StandardEmojiCategory> =
    listOf(
      StandardEmojiCategory(
        id = "happy",
        icon = "😀",
        title = "Happy & Smiling",
        emojis =
          listOf(
            "😀" to "grinning happy", "😃" to "smiley", "😄" to "smile", "😁" to "beam",
            "😊" to "blush happy", "😇" to "angel innocent", "🙂" to "slight smile",
            "☺️" to "warm smile", "😌" to "relieved", "🥳" to "party", "🤩" to "star eyes",
            "😎" to "cool shades",
          ),
      ),
      StandardEmojiCategory(
        id = "funny",
        icon = "😂",
        title = "Funny & Laughing",
        emojis =
          listOf(
            "😂" to "laugh tears lol", "🤣" to "rofl funny", "😆" to "laughing",
            "😜" to "wink tongue silly", "😝" to "squint tongue", "🤪" to "zany crazy",
            "🤭" to "giggle", "😏" to "smirk", "🤡" to "clown", "🙃" to "upside down",
          ),
      ),
      StandardEmojiCategory(
        id = "love",
        icon = "❤️",
        title = "Love & Friendship",
        emojis =
          listOf(
            "❤️" to "red heart love", "🩷" to "pink heart", "🩵" to "crystal blue heart",
            "💜" to "purple heart", "😍" to "love eyes", "🥰" to "hearts happy",
            "😘" to "kiss heart", "🫶" to "friendship heart hands", "🤗" to "hug",
            "🫂" to "friends hug", "💖" to "sparkling heart", "💘" to "cupid",
          ),
      ),
      StandardEmojiCategory(
        id = "sad",
        icon = "😢",
        title = "Sad & Emotional",
        emojis =
          listOf(
            "😢" to "cry sad", "😭" to "loud crying", "🥺" to "pleading puppy eyes",
            "😔" to "pensive", "😞" to "disappointed", "💔" to "broken heart",
            "🥹" to "holding tears", "😥" to "sad sweat",
          ),
      ),
      StandardEmojiCategory(
        id = "angry",
        icon = "😡",
        title = "Angry & Annoyed",
        emojis =
          listOf(
            "😡" to "angry mad", "😠" to "annoyed", "🤬" to "furious", "😤" to "huff steam",
            "😒" to "unamused", "🙄" to "eye roll", "😾" to "grumpy",
          ),
      ),
      StandardEmojiCategory(
        id = "shocked",
        icon = "😱",
        title = "Shocked & Surprised",
        emojis =
          listOf(
            "😱" to "scream shocked", "😲" to "surprised", "😮" to "open mouth wow",
            "🤯" to "mind blown", "😳" to "flushed", "🫣" to "peeking shy", "🤔" to "thinking",
          ),
      ),
      StandardEmojiCategory(
        id = "sleepy",
        icon = "😴",
        title = "Sleepy & Relaxed",
        emojis =
          listOf(
            "😴" to "sleeping zzz", "🥱" to "yawn tired", "😪" to "sleepy", "💤" to "zzz sleep",
            "🧘" to "meditate calm", "☕" to "tea coffee chill", "🌙" to "goodnight moon",
          ),
      ),
      StandardEmojiCategory(
        id = "animals",
        icon = "🐼",
        title = "Cute Animals",
        emojis =
          listOf(
            "🐼" to "panda", "🐰" to "bunny rabbit", "🐱" to "cat kitty", "🐶" to "puppy dog",
            "🦊" to "fox", "🐻" to "bear", "🐨" to "koala", "🦁" to "lion",
            "🦄" to "unicorn", "🐧" to "penguin", "🐸" to "frog", "🦋" to "butterfly",
          ),
      ),
      StandardEmojiCategory(
        id = "hands",
        icon = "👋",
        title = "Hand Gestures",
        emojis =
          listOf(
            "👋" to "wave hello hi", "🙏" to "namaste thank you please", "👍" to "thumbs up ok",
            "👎" to "thumbs down", "👏" to "clap bravo", "🙌" to "celebrate hands",
            "🤝" to "handshake", "✌️" to "peace victory", "👌" to "ok perfect", "💪" to "strong",
          ),
      ),
      StandardEmojiCategory(
        id = "celebrations",
        icon = "🎉",
        title = "Birthday & Celebrations",
        emojis =
          listOf(
            "🎉" to "party popper", "🎂" to "birthday cake", "🎈" to "balloon", "🎁" to "gift",
            "🎊" to "confetti", "🥂" to "cheers", "✨" to "sparkles", "🏆" to "trophy",
          ),
      ),
      StandardEmojiCategory(
        id = "indian_festivals",
        icon = "🇮🇳",
        title = "Indian Festivals",
        emojis =
          listOf(
            "🇮🇳" to "india tiranga", "🪔" to "diya diwali deepavali", "🎆" to "fireworks diwali",
            "🎇" to "sparkler", "🪁" to "kite makar sankranti", "🕉️" to "om", "🪷" to "lotus",
            "🥁" to "dhol", "🍬" to "mithai sweet", "🙏" to "namaste pranam",
          ),
      ),
      StandardEmojiCategory(
        id = "food",
        icon = "🍕",
        title = "Food & Drinks",
        emojis =
          listOf(
            "🍕" to "pizza", "🍔" to "burger", "🍛" to "curry biryani", "🥘" to "food",
            "🍜" to "noodles", "🍩" to "donut", "🍦" to "ice cream", "🍓" to "strawberry",
            "☕" to "chai coffee", "🧋" to "boba tea",
          ),
      ),
      StandardEmojiCategory(
        id = "sports",
        icon = "⚽",
        title = "Sports",
        emojis =
          listOf(
            "🏏" to "cricket bat ball", "⚽" to "football soccer", "🏀" to "basketball",
            "🏸" to "badminton", "🎾" to "tennis", "🏅" to "medal", "🥇" to "gold",
          ),
      ),
      StandardEmojiCategory(
        id = "education",
        icon = "📚",
        title = "Education",
        emojis =
          listOf(
            "📚" to "books study", "🎓" to "graduation", "✏️" to "pencil", "💡" to "idea bulb",
            "💻" to "laptop code", "🔬" to "science", "📝" to "notes exam",
          ),
      ),
      StandardEmojiCategory(
        id = "travel",
        icon = "🌍",
        title = "Nature & Travel",
        emojis =
          listOf(
            "🌍" to "earth world", "🏔️" to "mountain", "🏖️" to "beach", "✈️" to "flight travel",
            "🌸" to "flower blossom", "🌻" to "sunflower", "🌴" to "palm tree",
          ),
      ),
      StandardEmojiCategory(
        id = "vehicles",
        icon = "🚗",
        title = "Vehicles",
        emojis =
          listOf(
            "🚗" to "car", "🏍️" to "motorcycle bike", "🚀" to "rocket", "🚆" to "train",
            "🛺" to "auto rickshaw", "🚌" to "bus", "🚁" to "helicopter",
          ),
      ),
      StandardEmojiCategory(
        id = "weather",
        icon = "🌈",
        title = "Weather",
        emojis =
          listOf(
            "🌈" to "rainbow", "☀️" to "sun sunny", "🌤️" to "partly sunny", "🌧️" to "rain",
            "⚡" to "lightning", "❄️" to "snow", "⭐" to "star",
          ),
      ),
      StandardEmojiCategory(
        id = "gaming",
        icon = "🎮",
        title = "Gaming",
        emojis =
          listOf(
            "🎮" to "controller gaming", "🕹️" to "joystick", "👾" to "alien retro",
            "🎲" to "dice", "♟️" to "chess", "🎯" to "target", "🔥" to "fire streak",
          ),
      ),
      StandardEmojiCategory(
        id = "music",
        icon = "🎵",
        title = "Music",
        emojis =
          listOf(
            "🎵" to "music note", "🎶" to "melody", "🎧" to "headphones", "🎤" to "mic sing",
            "🎸" to "guitar", "🎹" to "piano", "💃" to "dance",
          ),
      ),
    )

  val allCustomEmojis: List<MsgUCustomEmoji> = crystalJelly20 + funnyAnimated

  // Backward-compatible aliases so any messages sent with earlier tokens render with the new 3D artwork
  private val legacyTokenAliases: Map<String, MsgUCustomEmoji> by lazy {
    val byId = crystalJelly20.associateBy { it.token }
    mapOf(
      "[jelly:aqua_joy]" to byId.getValue("[jelly:sweet_happy]"),
      "[jelly:cobalt_love]" to byId.getValue("[jelly:love_eyes]"),
      "[jelly:mint_chill]" to byId.getValue("[jelly:cool_cartoon]"),
      "[jelly:star_beam]" to byId.getValue("[jelly:sparkling_eyes]"),
      "[jelly:berry_wink]" to byId.getValue("[jelly:funny_tongue]"),
      "[jelly:coral_hug]" to byId.getValue("[jelly:friendship]"),
      "[jelly:prism_laugh]" to byId.getValue("[jelly:funny_laugh]"),
      "[jelly:aurora_blush]" to byId.getValue("[jelly:shy_expression]"),
      "[jelly:peach_angel]" to byId.getValue("[jelly:innocent_smile]"),
      "[jelly:ice_shock]" to byId.getValue("[jelly:surprised]"),
      "[jelly:lagoon_think]" to byId.getValue("[jelly:thinking]"),
      "[jelly:neon_party]" to byId.getValue("[jelly:birthday]"),
      "[jelly:ruby_heart]" to byId.getValue("[jelly:crystal_heart]"),
      "[jelly:sapphire_fire]" to byId.getValue("[jelly:sparkling_eyes]"),
      "[jelly:crystal_spark]" to byId.getValue("[jelly:sparkling_eyes]"),
      "[jelly:sky_salute]" to byId.getValue("[jelly:cute_namaste]"),
      "[jelly:violet_dream]" to byId.getValue("[jelly:sleepy]"),
      "[jelly:emerald_ok]" to byId.getValue("[jelly:thumbs_up]"),
      "[jelly:amber_rocket]" to byId.getValue("[jelly:birthday]"),
      "[jelly:ocean_wave]" to byId.getValue("[jelly:happy_hello]"),
      "[anim:rofl_bounce]" to funnyAnimated[0],
      "[anim:party_pop]" to funnyAnimated[1],
      "[anim:dance_vibe]" to funnyAnimated[2],
    )
  }

  private val byToken: Map<String, MsgUCustomEmoji> by lazy {
    allCustomEmojis.associateBy { it.token } + legacyTokenAliases
  }

  fun findByToken(token: String): MsgUCustomEmoji? = byToken[token]

  fun previewLabel(text: String, messageType: MessageType): String {
    if (messageType == MessageType.TEXT) return text
    val emoji = byToken[text]
    return if (emoji != null) "${emoji.glyph} ${emoji.label}" else text
  }
}
