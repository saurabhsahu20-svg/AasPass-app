package com.example.ui.components

import android.provider.Settings
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.EmojiCatalog
import com.example.data.model.EmojiPack
import com.example.data.model.MessageType
import com.example.data.model.MsgUCustomEmoji
import com.example.ui.theme.ErrorRed
import kotlin.math.sin

@Composable
private fun rememberReducedMotionEnabled(): Boolean {
  val context = LocalContext.current
  return remember(context) {
    try {
      Settings.Global.getFloat(
        context.contentResolver,
        Settings.Global.ANIMATOR_DURATION_SCALE,
        1f,
      ) == 0f
    } catch (_: Exception) {
      false
    }
  }
}

@Composable
fun CrystalJellyEmojiView(
  emoji: MsgUCustomEmoji,
  size: Dp = 64.dp,
  modifier: Modifier = Modifier,
  animate: Boolean = emoji.pack == EmojiPack.FUNNY_ANIMATED,
) {
  val reducedMotion = rememberReducedMotionEnabled()
  val shouldAnimate = animate && !reducedMotion && emoji.animationKind != "none"

  val animModifier =
    if (shouldAnimate) {
      val infiniteTransition = rememberInfiniteTransition(label = "msgu_jelly_anim")
      val progress by
        infiniteTransition.animateFloat(
          initialValue = 0f,
          targetValue = 1f,
          animationSpec =
            infiniteRepeatable(
              animation =
                tween(
                  durationMillis =
                    when (emoji.animationKind) {
                      "heartbeat" -> 900
                      "jump", "bounce" -> 820
                      "float" -> 1800
                      else -> 1150
                    },
                  easing = FastOutSlowInEasing,
                ),
              repeatMode = RepeatMode.Reverse,
            ),
          label = "msgu_jelly_progress",
        )
      when (emoji.animationKind) {
        "bounce" ->
          Modifier.graphicsLayer {
            translationY = -progress * 10f
            scaleX = 1.03f - progress * 0.05f
            scaleY = 0.97f + progress * 0.06f
          }
        "jump" ->
          Modifier.graphicsLayer {
            translationY = -progress * 14f
            rotationZ = (progress - 0.5f) * 8f
            scaleX = 0.96f + progress * 0.08f
            scaleY = 0.96f + progress * 0.08f
          }
        "dance" ->
          Modifier.graphicsLayer {
            val wave = sin(progress * Math.PI).toFloat()
            rotationZ = (progress - 0.5f) * 16f
            translationY = -wave * 8f
            scaleX = 0.97f + wave * 0.07f
            scaleY = 0.97f + wave * 0.07f
          }
        "wiggle" ->
          Modifier.graphicsLayer {
            rotationZ = (progress - 0.5f) * 18f
          }
        "heartbeat" ->
          Modifier.graphicsLayer {
            val s = 0.94f + progress * 0.14f
            scaleX = s
            scaleY = s
          }
        "float" ->
          Modifier.graphicsLayer {
            translationY = (progress - 0.5f) * 10f
            rotationZ = (progress - 0.5f) * 5f
          }
        else ->
          Modifier.graphicsLayer {
            val s = 0.95f + progress * 0.10f
            scaleX = s
            scaleY = s
          }
      }
    } else {
      Modifier
    }

  Box(
    modifier = modifier.size(size).then(animModifier),
    contentAlignment = Alignment.Center,
  ) {
    val resId = emoji.drawableRes
    if (resId != null) {
      Image(
        painter = painterResource(id = resId),
        contentDescription = emoji.label,
        contentScale = ContentScale.Fit,
        modifier = Modifier.fillMaxSize(),
      )
    } else {
      Text(
        text = emoji.glyph,
        fontSize = (size.value * 0.56f).sp,
        textAlign = TextAlign.Center,
      )
    }
  }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MsgUEmojiKeyboard(
  recentEmojis: List<String> = emptyList(),
  favoriteEmojis: List<String> = emptyList(),
  onInsertUnicode: (String) -> Unit,
  onSendCustomEmoji: (token: String, type: MessageType) -> Unit,
  onToggleFavoriteEmoji: (String) -> Unit = {},
  modifier: Modifier = Modifier,
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  var selectedCategoryIndex by remember { mutableIntStateOf(0) }
  var searchQuery by remember { mutableStateOf("") }
  var previewEmoji by remember { mutableStateOf<MsgUCustomEmoji?>(null) }

  val tabs =
    listOf(
      "💎 Crystal 3D",
      "😂 Animated",
      "🕒 Recent",
      "⭐ Favorites",
      "😀 Categories",
    )

  Surface(
    modifier = modifier.fillMaxWidth().height(344.dp),
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = 4.dp,
  ) {
    Column(modifier = Modifier.fillMaxSize().padding(top = 8.dp)) {
      // Compact Search Bar
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp).height(40.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Icon(
            imageVector = Icons.Default.Search,
            contentDescription = "Search emojis",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (searchQuery.isEmpty()) {
              Text(
                text = "Search Crystal 3D, Namaste, Love, Birthday…",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
            BasicTextField(
              value = searchQuery,
              onValueChange = { searchQuery = it.take(40) },
              singleLine = true,
              textStyle =
                MaterialTheme.typography.bodyMedium.copy(
                  color = MaterialTheme.colorScheme.onSurface
                ),
              cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
              modifier = Modifier.fillMaxWidth().testTag("emoji_search_input"),
            )
          }
          if (searchQuery.isNotEmpty()) {
            IconButton(
              onClick = { searchQuery = "" },
              modifier = Modifier.size(28.dp),
            ) {
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Clear search",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp),
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      if (searchQuery.isNotBlank()) {
        val q = searchQuery.trim().lowercase()
        val matchingCustom =
          remember(q) {
            EmojiCatalog.allCustomEmojis.filter { e ->
              e.label.lowercase().contains(q) ||
                e.glyph.contains(q) ||
                e.keywords.any { it.contains(q) }
            }
          }
        val matchingStandard =
          remember(q) {
            EmojiCatalog.standardCategories
              .flatMap { cat ->
                cat.emojis.filter { (glyph, desc) ->
                  glyph.contains(q) ||
                    desc.lowercase().contains(q) ||
                    cat.title.lowercase().contains(q)
                }
              }
              .map { it.first }
              .distinct()
          }

        if (matchingCustom.isEmpty() && matchingStandard.isEmpty()) {
          Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
              text = "No matching emojis for \"$searchQuery\"",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        } else {
          Column(modifier = Modifier.fillMaxSize()) {
            if (matchingCustom.isNotEmpty()) {
              Text(
                text = "MsgU Crystal 3D (${matchingCustom.size})",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 2.dp),
              )
              CustomEmojiPackGrid(
                items = matchingCustom,
                favoriteTokens = favoriteEmojis.toSet(),
                onPick = { item ->
                  val type =
                    if (item.pack == EmojiPack.CRYSTAL_JELLY) MessageType.JELLY_EMOJI
                    else MessageType.CARTOON_EMOJI
                  onSendCustomEmoji(item.token, type)
                },
                onLongPress = { previewEmoji = it },
                modifier = Modifier.weight(1f),
              )
            }
            if (matchingStandard.isNotEmpty()) {
              LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                items(matchingStandard) { glyph ->
                  StandardEmojiTile(glyph = glyph, onClick = { onInsertUnicode(glyph) })
                }
              }
            }
          }
        }
      } else {
        // Collection Tabs
        LazyRow(
          contentPadding = PaddingValues(horizontal = 12.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          itemsIndexed(tabs) { index, title ->
            FilterChip(
              selected = selectedTab == index,
              onClick = { selectedTab = index },
              label = {
                Text(
                  text = title,
                  style = MaterialTheme.typography.labelSmall,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              },
              modifier = Modifier.testTag("emoji_tab_$index"),
            )
          }
        }

        Spacer(modifier = Modifier.height(4.dp))

        when (selectedTab) {
          0 -> {
            Column(modifier = Modifier.fillMaxSize()) {
              Text(
                text = "Tap to send • Long-press for large preview & favorite",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 2.dp),
              )
              CustomEmojiPackGrid(
                items = EmojiCatalog.crystalJelly20,
                favoriteTokens = favoriteEmojis.toSet(),
                onPick = { onSendCustomEmoji(it.token, MessageType.JELLY_EMOJI) },
                onLongPress = { previewEmoji = it },
                modifier = Modifier.weight(1f),
              )
            }
          }
          1 -> {
            CustomEmojiPackGrid(
              items = EmojiCatalog.funnyAnimated,
              favoriteTokens = favoriteEmojis.toSet(),
              onPick = { onSendCustomEmoji(it.token, MessageType.CARTOON_EMOJI) },
              onLongPress = { previewEmoji = it },
              modifier = Modifier.fillMaxSize(),
            )
          }
          2 -> {
            SavedEmojiCollectionView(
              tokensAndGlyphs = recentEmojis,
              favoriteTokens = favoriteEmojis.toSet(),
              emptyTitle = "No recent emojis yet",
              emptySubtitle = "Your recently sent Crystal 3D and standard emojis appear here.",
              onInsertUnicode = onInsertUnicode,
              onSendCustomEmoji = onSendCustomEmoji,
              onLongPressCustom = { previewEmoji = it },
            )
          }
          3 -> {
            SavedEmojiCollectionView(
              tokensAndGlyphs = favoriteEmojis,
              favoriteTokens = favoriteEmojis.toSet(),
              emptyTitle = "No favorite emojis yet",
              emptySubtitle = "Long-press any Crystal 3D emoji to star it as a favorite.",
              onInsertUnicode = onInsertUnicode,
              onSendCustomEmoji = onSendCustomEmoji,
              onLongPressCustom = { previewEmoji = it },
            )
          }
          else -> {
            Column(modifier = Modifier.fillMaxSize()) {
              LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                itemsIndexed(EmojiCatalog.standardCategories) { idx, category ->
                  val selected = selectedCategoryIndex == idx
                  Surface(
                    shape = RoundedCornerShape(12.dp),
                    color =
                      if (selected) MaterialTheme.colorScheme.primaryContainer
                      else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    onClick = { selectedCategoryIndex = idx },
                  ) {
                    Row(
                      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                      verticalAlignment = Alignment.CenterVertically,
                    ) {
                      Text(text = category.icon, fontSize = 15.sp)
                      Spacer(modifier = Modifier.width(4.dp))
                      Text(
                        text = category.title,
                        style = MaterialTheme.typography.labelSmall,
                        color =
                          if (selected) MaterialTheme.colorScheme.onPrimaryContainer
                          else MaterialTheme.colorScheme.onSurfaceVariant,
                      )
                    }
                  }
                }
              }

              val currentCat =
                EmojiCatalog.standardCategories.getOrElse(selectedCategoryIndex) {
                  EmojiCatalog.standardCategories.first()
                }
              LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 48.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.weight(1f),
              ) {
                items(currentCat.emojis, key = { "${currentCat.id}_${it.first}" }) { (glyph, _) ->
                  StandardEmojiTile(glyph = glyph, onClick = { onInsertUnicode(glyph) })
                }
              }
            }
          }
        }
      }
    }
  }

  val preview = previewEmoji
  if (preview != null) {
    val isFav = preview.token in favoriteEmojis
    Dialog(onDismissRequest = { previewEmoji = null }) {
      Surface(
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
      ) {
        Column(
          modifier = Modifier.padding(24.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
          ) {
            Text(
              text = preview.pack.title,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onPrimaryContainer,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            )
          }
          Spacer(modifier = Modifier.height(14.dp))
          CrystalJellyEmojiView(
            emoji = preview,
            size = 160.dp,
            animate = preview.pack == EmojiPack.FUNNY_ANIMATED,
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = preview.label,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Spacer(modifier = Modifier.height(18.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            OutlinedButton(
              onClick = { onToggleFavoriteEmoji(preview.token) },
              shape = RoundedCornerShape(14.dp),
              modifier = Modifier.weight(1f).height(48.dp),
            ) {
              Icon(
                imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = if (isFav) "Remove favorite" else "Add favorite",
                tint = if (isFav) ErrorRed else MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (isFav) "Saved" else "Favorite")
            }
            Button(
              onClick = {
                val type =
                  if (preview.pack == EmojiPack.CRYSTAL_JELLY) MessageType.JELLY_EMOJI
                  else MessageType.CARTOON_EMOJI
                onSendCustomEmoji(preview.token, type)
                previewEmoji = null
              },
              shape = RoundedCornerShape(14.dp),
              modifier = Modifier.weight(1f).height(48.dp),
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.Send,
                contentDescription = "Send emoji",
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text("Send")
            }
          }
        }
      }
    }
  }
}

@Composable
private fun StandardEmojiTile(
  glyph: String,
  onClick: () -> Unit,
) {
  Box(
    modifier =
      Modifier.size(48.dp)
        .clip(RoundedCornerShape(12.dp))
        .clickable(onClick = onClick),
    contentAlignment = Alignment.Center,
  ) {
    Text(text = glyph, fontSize = 25.sp)
  }
}

@Composable
private fun SavedEmojiCollectionView(
  tokensAndGlyphs: List<String>,
  favoriteTokens: Set<String>,
  emptyTitle: String,
  emptySubtitle: String,
  onInsertUnicode: (String) -> Unit,
  onSendCustomEmoji: (token: String, type: MessageType) -> Unit,
  onLongPressCustom: (MsgUCustomEmoji) -> Unit,
) {
  if (tokensAndGlyphs.isEmpty()) {
    Box(modifier = Modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.Center) {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
          text = emptyTitle,
          style = MaterialTheme.typography.titleSmall,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = emptySubtitle,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          textAlign = TextAlign.Center,
        )
      }
    }
    return
  }

  val customItems = remember(tokensAndGlyphs) { tokensAndGlyphs.mapNotNull { EmojiCatalog.findByToken(it) }.distinctBy { it.token } }
  val standardGlyphs = remember(tokensAndGlyphs) { tokensAndGlyphs.filter { EmojiCatalog.findByToken(it) == null }.distinct() }

  Column(modifier = Modifier.fillMaxSize()) {
    if (standardGlyphs.isNotEmpty()) {
      LazyRow(
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        items(standardGlyphs) { glyph ->
          StandardEmojiTile(glyph = glyph, onClick = { onInsertUnicode(glyph) })
        }
      }
    }
    if (customItems.isNotEmpty()) {
      CustomEmojiPackGrid(
        items = customItems,
        favoriteTokens = favoriteTokens,
        onPick = { item ->
          val type =
            if (item.pack == EmojiPack.CRYSTAL_JELLY) MessageType.JELLY_EMOJI
            else MessageType.CARTOON_EMOJI
          onSendCustomEmoji(item.token, type)
        },
        onLongPress = onLongPressCustom,
        modifier = Modifier.weight(1f),
      )
    }
  }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CustomEmojiPackGrid(
  items: List<MsgUCustomEmoji>,
  favoriteTokens: Set<String>,
  onPick: (MsgUCustomEmoji) -> Unit,
  onLongPress: (MsgUCustomEmoji) -> Unit,
  modifier: Modifier = Modifier,
) {
  LazyVerticalGrid(
    columns = GridCells.Adaptive(minSize = 78.dp),
    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp),
    modifier = modifier,
  ) {
    items(items, key = { it.token }) { item ->
      Box(
        modifier =
          Modifier.clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.40f))
            .combinedClickable(
              onClick = { onPick(item) },
              onLongClick = { onLongPress(item) },
            )
            .padding(vertical = 8.dp, horizontal = 4.dp)
            .testTag("custom_emoji_${item.token}"),
        contentAlignment = Alignment.Center,
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          CrystalJellyEmojiView(emoji = item, size = 54.dp)
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = item.label,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        if (item.token in favoriteTokens) {
          Box(
            modifier =
              Modifier.align(Alignment.TopEnd)
                .padding(2.dp)
                .size(16.dp)
                .clip(CircleShape)
                .background(ErrorRed.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Default.Favorite,
              contentDescription = "Favorite",
              tint = ErrorRed,
              modifier = Modifier.size(11.dp),
            )
          }
        }
      }
    }
  }
}
