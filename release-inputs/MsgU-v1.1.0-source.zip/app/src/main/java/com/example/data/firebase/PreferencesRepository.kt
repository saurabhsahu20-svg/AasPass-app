package com.example.data.firebase

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.theme.ThemePreference
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.msgUPreferencesDataStore: DataStore<Preferences> by
  preferencesDataStore(name = "msgu_preferences")

data class MsgUSettings(
  val themePreference: ThemePreference = ThemePreference.SYSTEM,
  val notificationsEnabled: Boolean = true,
  val showMessagePreviews: Boolean = true,
  val sendReadReceipts: Boolean = true,
  val recentEmojis: List<String> = emptyList(),
  val favoriteEmojis: List<String> = emptyList(),
)

class PreferencesRepository(private val context: Context) {
  private object Keys {
    val THEME = stringPreferencesKey("theme_preference")
    val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
    val SHOW_PREVIEWS = booleanPreferencesKey("show_message_previews")
    val READ_RECEIPTS = booleanPreferencesKey("send_read_receipts")
    val RECENT_EMOJIS = stringPreferencesKey("recent_emojis")
    val FAVORITE_EMOJIS = stringPreferencesKey("favorite_emojis")
  }

  val settingsFlow: Flow<MsgUSettings> =
    context.applicationContext.msgUPreferencesDataStore.data.map { prefs ->
      val theme =
        enumValues<ThemePreference>().firstOrNull { it.name == prefs[Keys.THEME] }
          ?: ThemePreference.SYSTEM
      val recents =
        prefs[Keys.RECENT_EMOJIS]
          ?.split("|")
          ?.filter { it.isNotBlank() }
          .orEmpty()
      val favorites =
        prefs[Keys.FAVORITE_EMOJIS]
          ?.split("|")
          ?.filter { it.isNotBlank() }
          .orEmpty()
      MsgUSettings(
        themePreference = theme,
        notificationsEnabled = prefs[Keys.NOTIFICATIONS_ENABLED] ?: true,
        showMessagePreviews = prefs[Keys.SHOW_PREVIEWS] ?: true,
        sendReadReceipts = prefs[Keys.READ_RECEIPTS] ?: true,
        recentEmojis = recents,
        favoriteEmojis = favorites,
      )
    }

  suspend fun setThemePreference(theme: ThemePreference) {
    context.applicationContext.msgUPreferencesDataStore.edit { prefs ->
      prefs[Keys.THEME] = theme.name
    }
  }

  suspend fun setNotificationsEnabled(enabled: Boolean) {
    context.applicationContext.msgUPreferencesDataStore.edit { prefs ->
      prefs[Keys.NOTIFICATIONS_ENABLED] = enabled
    }
  }

  suspend fun setShowMessagePreviews(enabled: Boolean) {
    context.applicationContext.msgUPreferencesDataStore.edit { prefs ->
      prefs[Keys.SHOW_PREVIEWS] = enabled
    }
  }

  suspend fun setSendReadReceipts(enabled: Boolean) {
    context.applicationContext.msgUPreferencesDataStore.edit { prefs ->
      prefs[Keys.READ_RECEIPTS] = enabled
    }
  }

  suspend fun recordRecentEmoji(tokenOrGlyph: String) {
    val clean = tokenOrGlyph.trim()
    if (clean.isEmpty()) return
    context.applicationContext.msgUPreferencesDataStore.edit { prefs ->
      val current =
        prefs[Keys.RECENT_EMOJIS]
          ?.split("|")
          ?.filter { it.isNotBlank() }
          .orEmpty()
      val updated = (listOf(clean) + current.filterNot { it == clean }).take(24)
      prefs[Keys.RECENT_EMOJIS] = updated.joinToString("|")
    }
  }

  suspend fun toggleFavoriteEmoji(tokenOrGlyph: String) {
    val clean = tokenOrGlyph.trim()
    if (clean.isEmpty()) return
    context.applicationContext.msgUPreferencesDataStore.edit { prefs ->
      val current =
        prefs[Keys.FAVORITE_EMOJIS]
          ?.split("|")
          ?.filter { it.isNotBlank() }
          .orEmpty()
      val updated =
        if (clean in current) current.filterNot { it == clean }
        else (listOf(clean) + current).take(40)
      prefs[Keys.FAVORITE_EMOJIS] = updated.joinToString("|")
    }
  }
}
