package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.ChatRepository
import com.example.data.firebase.MsgUSettings
import com.example.data.firebase.PreferencesRepository
import com.example.data.firebase.UserRepository
import com.example.data.firebase.toUserFriendlyFirestoreMessage
import com.example.data.model.ContactEntry
import com.example.data.model.Conversation
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.ui.theme.ThemePreference
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class IncomingNotificationEvent(
  val conversationId: String,
  val peerUid: String,
  val senderName: String,
  val senderPhotoUrl: String,
  val previewText: String,
  val unreadCount: Int,
  val showPreview: Boolean,
  val eventId: Long = System.currentTimeMillis(),
)

data class UserSearchUiState(
  val query: String = "",
  val isSearching: Boolean = false,
  val hasSearched: Boolean = false,
  val foundUser: UserProfile? = null,
  val errorMessage: String? = null,
  val isStartingChat: Boolean = false,
)

private data class ConversationSnapshotTrack(
  val lastMessageAtMs: Long,
  val unreadCount: Int,
  val lastMessageText: String,
)

class HomeViewModel(
  private val userRepository: UserRepository,
  private val chatRepository: ChatRepository,
  private val preferencesRepository: PreferencesRepository,
  val currentUserId: String,
) : ViewModel() {

  @Volatile private var activeConversationId: String? = null
  private var baselineSeeded = false
  private val trackedConversations = mutableMapOf<String, ConversationSnapshotTrack>()

  private val _incomingNotifications =
    MutableSharedFlow<IncomingNotificationEvent>(extraBufferCapacity = 32)
  val incomingNotifications: SharedFlow<IncomingNotificationEvent> =
    _incomingNotifications.asSharedFlow()

  private val _inAppBanner = MutableStateFlow<IncomingNotificationEvent?>(null)
  val inAppBanner: StateFlow<IncomingNotificationEvent?> = _inAppBanner.asStateFlow()

  val settingsState: StateFlow<MsgUSettings> =
    preferencesRepository.settingsFlow.stateIn(
      scope = viewModelScope,
      started = SharingStarted.Eagerly,
      initialValue = MsgUSettings(),
    )

  val currentUserProfile: StateFlow<UiState<UserProfile?>> =
    userRepository
      .observeCurrentUserProfile(currentUserId)
      .map<UserProfile?, UiState<UserProfile?>> { UiState.Success(it) }
      .catch { error ->
        val firestoreError =
          generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, "Error observing profile", rootError)
        emit(UiState.Error(rootError.toUserFriendlyFirestoreMessage()))
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = UiState.Loading,
      )

  // CRITICAL: SharingStarted.Eagerly keeps the real-time conversation listener active across
  // ChatScreen, Search, Settings, and background transitions so incoming notifications ALWAYS fire.
  val conversationsState: StateFlow<UiState<List<Conversation>>> =
    chatRepository
      .observeConversations(currentUserId)
      .onEach { list -> processIncomingNotifications(list) }
      .map<List<Conversation>, UiState<List<Conversation>>> { UiState.Success(it) }
      .catch { error ->
        val firestoreError =
          generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, "Error observing conversations", rootError)
        emit(UiState.Error(rootError.toUserFriendlyFirestoreMessage()))
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = UiState.Loading,
      )

  val contactsState: StateFlow<UiState<List<ContactEntry>>> =
    userRepository
      .observeContacts(currentUserId)
      .map<List<ContactEntry>, UiState<List<ContactEntry>>> { UiState.Success(it) }
      .catch { error ->
        val firestoreError =
          generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, "Error observing contacts", rootError)
        emit(UiState.Error(rootError.toUserFriendlyFirestoreMessage()))
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
        initialValue = UiState.Loading,
      )

  private val _chatFilterQuery = MutableStateFlow("")
  val chatFilterQuery: StateFlow<String> = _chatFilterQuery.asStateFlow()

  private val _searchState = MutableStateFlow(UserSearchUiState())
  val searchState: StateFlow<UserSearchUiState> = _searchState.asStateFlow()

  private val _actionMessage = MutableStateFlow<String?>(null)
  val actionMessage: StateFlow<String?> = _actionMessage.asStateFlow()

  init {
    startPresenceHeartbeat()
  }

  private fun startPresenceHeartbeat() {
    viewModelScope.launch {
      while (isActive) {
        if ((currentUserProfile.value as? UiState.Success)?.data != null) {
          userRepository.updatePresence(currentUserId)
        }
        delay(PRESENCE_INTERVAL_MS)
      }
    }
  }

  fun pingPresenceNow() {
    viewModelScope.launch {
      if ((currentUserProfile.value as? UiState.Success)?.data != null) {
        userRepository.updatePresence(currentUserId)
      }
    }
  }

  private fun processIncomingNotifications(conversations: List<Conversation>) {
    if (!baselineSeeded) {
      conversations.forEach { conv ->
        val ts = (conv.lastMessageAt ?: conv.updatedAt)?.toDate()?.time ?: 0L
        trackedConversations[conv.id] =
          ConversationSnapshotTrack(
            lastMessageAtMs = ts,
            unreadCount = conv.unreadCountFor(currentUserId).toInt(),
            lastMessageText = conv.lastMessageText,
          )
      }
      baselineSeeded = true
      return
    }

    val settings = settingsState.value
    conversations.forEach { conv ->
      val msgTs = (conv.lastMessageAt ?: conv.updatedAt)?.toDate()?.time ?: 0L
      val unread = conv.unreadCountFor(currentUserId).toInt()
      val prev = trackedConversations[conv.id]

      val isNewIncomingMessage =
        unread > 0 &&
          conv.lastMessageSenderId.isNotBlank() &&
          conv.lastMessageSenderId != currentUserId &&
          conv.id != activeConversationId &&
          (prev == null ||
            msgTs > prev.lastMessageAtMs ||
            unread > prev.unreadCount ||
            (conv.lastMessageText.isNotBlank() && conv.lastMessageText != prev.lastMessageText))

      trackedConversations[conv.id] =
        ConversationSnapshotTrack(
          lastMessageAtMs = maxOf(msgTs, prev?.lastMessageAtMs ?: 0L),
          unreadCount = unread,
          lastMessageText = conv.lastMessageText,
        )

      if (isNewIncomingMessage && settings.notificationsEnabled) {
        val event =
          IncomingNotificationEvent(
            conversationId = conv.id,
            peerUid = conv.peerUid(currentUserId),
            senderName = conv.peerDisplayName(currentUserId),
            senderPhotoUrl = conv.peerPhotoUrl(currentUserId),
            previewText = conv.lastMessageText,
            unreadCount = unread,
            showPreview = settings.showMessagePreviews,
          )
        _incomingNotifications.tryEmit(event)
        _inAppBanner.value = event
      }
    }
  }

  fun dismissInAppBanner() {
    _inAppBanner.value = null
  }

  fun setActiveConversation(conversationId: String?) {
    activeConversationId = conversationId
    if (conversationId != null && _inAppBanner.value?.conversationId == conversationId) {
      _inAppBanner.value = null
    }
  }

  fun setNotificationsEnabled(enabled: Boolean) {
    viewModelScope.launch { preferencesRepository.setNotificationsEnabled(enabled) }
  }

  fun updateChatFilterQuery(query: String) {
    _chatFilterQuery.value = query
  }

  fun updateSearchQuery(query: String) {
    _searchState.update {
      it.copy(query = query, errorMessage = null, hasSearched = false, foundUser = null)
    }
  }

  fun performUserSearch() {
    val raw = _searchState.value.query.trim()
    if (raw.isBlank()) {
      _searchState.update { it.copy(errorMessage = "Enter a @username to search.") }
      return
    }
    viewModelScope.launch {
      _searchState.update {
        it.copy(isSearching = true, errorMessage = null, foundUser = null, hasSearched = false)
      }
      val result = userRepository.searchByExactUsername(raw)
      result.fold(
        onSuccess = { user ->
          _searchState.update {
            it.copy(
              isSearching = false,
              hasSearched = true,
              foundUser = user,
              errorMessage = if (user == null) "No MsgU user found with @$raw" else null,
            )
          }
        },
        onFailure = { err ->
          _searchState.update {
            it.copy(
              isSearching = false,
              hasSearched = true,
              foundUser = null,
              errorMessage = err.toUserFriendlyFirestoreMessage(),
            )
          }
        },
      )
    }
  }

  fun startConversationWithUser(
    peerUser: UserProfile,
    onConversationReady: (conversationId: String, peerUid: String) -> Unit,
  ) {
    val currentProfile = (currentUserProfile.value as? UiState.Success)?.data
    if (currentProfile == null) {
      _actionMessage.value = "Complete your profile setup first."
      return
    }
    if (peerUser.userId == currentUserId) {
      _searchState.update { it.copy(errorMessage = "You cannot start a chat with yourself.") }
      return
    }

    viewModelScope.launch {
      _searchState.update { it.copy(isStartingChat = true, errorMessage = null) }
      // Launch contact save in parallel so opening chat feels instantaneous!
      launch { userRepository.upsertContact(peerUser) }
      val result = chatRepository.ensureConversation(currentProfile, peerUser)
      _searchState.update { it.copy(isStartingChat = false) }
      result.fold(
        onSuccess = { convId -> onConversationReady(convId, peerUser.userId) },
        onFailure = { err ->
          val msg = err.toUserFriendlyFirestoreMessage()
          _searchState.update { it.copy(errorMessage = msg) }
          _actionMessage.value = msg
        },
      )
    }
  }

  fun toggleFavoriteContact(contact: ContactEntry) {
    viewModelScope.launch {
      val profile =
        UserProfile(
          userId = contact.contactUid,
          username = contact.username,
          displayName = contact.displayName,
          photoUrl = contact.photoUrl,
        )
      userRepository
        .setContactFavorite(profile, !contact.favorite)
        .onFailure { _actionMessage.value = it.toUserFriendlyFirestoreMessage() }
    }
  }

  fun toggleBlockedContact(contact: ContactEntry) {
    viewModelScope.launch {
      val profile =
        UserProfile(
          userId = contact.contactUid,
          username = contact.username,
          displayName = contact.displayName,
          photoUrl = contact.photoUrl,
        )
      userRepository
        .setContactBlocked(profile, !contact.blocked)
        .onSuccess {
          _actionMessage.value =
            if (!contact.blocked) "Blocked @${contact.username}" else "Unblocked @${contact.username}"
        }
        .onFailure { _actionMessage.value = it.toUserFriendlyFirestoreMessage() }
    }
  }

  fun savePeerAsContact(peerUser: UserProfile) {
    viewModelScope.launch {
      userRepository
        .upsertContact(peerUser)
        .onSuccess { _actionMessage.value = "Saved @${peerUser.username} to Contacts" }
        .onFailure { _actionMessage.value = it.toUserFriendlyFirestoreMessage() }
    }
  }

  fun setThemePreference(theme: ThemePreference) {
    viewModelScope.launch { preferencesRepository.setThemePreference(theme) }
  }

  fun setShowMessagePreviews(enabled: Boolean) {
    viewModelScope.launch { preferencesRepository.setShowMessagePreviews(enabled) }
  }

  fun setSendReadReceipts(enabled: Boolean) {
    viewModelScope.launch { preferencesRepository.setSendReadReceipts(enabled) }
  }

  fun clearActionMessage() {
    _actionMessage.value = null
  }

  private companion object {
    const val TAG = "HomeVM"
    const val STOP_TIMEOUT_MS = 5000L
    const val PRESENCE_INTERVAL_MS = 45_000L
  }
}
